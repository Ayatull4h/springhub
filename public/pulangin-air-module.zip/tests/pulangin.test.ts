// Run: npx tsx --test tests/pulangin.test.ts
import assert from "node:assert/strict";
import { test } from "node:test";
import sharp from "sharp";
import { runAutoChecks, type CheckContext, type UnitSubmission } from "../lib/pulangin/checks";
import { builderFeeIdr, orderTotalIdr, platformFeeIdr } from "../lib/pulangin/config";
import { bboxAround, cellIdOf, distanceM } from "../lib/pulangin/geo";
import { dHash, hamming } from "../lib/pulangin/phash";
import { deriveOrderStatus, freeSlots, makeOrderCode, owedOnClaim, validateClaim } from "../lib/pulangin/state";

const center = { lat: -7.7956, lng: 110.3695 };
const now = new Date("2026-10-19T03:00:00Z");

function sub(over: Partial<UnitSubmission> = {}): UnitSubmission {
  return {
    point: { lat: center.lat + 0.001, lng: center.lng },
    accuracyM: 6,
    capturedAt: new Date(now.getTime() - 5 * 60_000),
    receivedAt: now,
    liveCapture: true,
    queuedOffline: false,
    photoHash: "ffff0000ffff0000",
    structureType: "Rorak",
    shape: "Kotak",
    lengthCm: 120,
    widthCm: 40,
    depthCm: 40,
    ...over,
  };
}
function ctx(over: Partial<CheckContext> = {}): CheckContext {
  return {
    order: { center, radiusM: 500 },
    claim: { createdAt: "2026-10-10T00:00:00Z", expiresAt: "2026-10-24T00:00:00Z" },
    nearbyUnits: [],
    unitsInCell: 0,
    knownPhotoHashes: [],
    random: () => 0.99,
    ...over,
  };
}
const level = (o: ReturnType<typeof runAutoChecks>, id: string) => o.checks.find((c) => c.id === id)?.level;

test("geo: distance and cells", () => {
  const d = distanceM(center, { lat: center.lat + 0.001, lng: center.lng });
  assert.ok(d > 105 && d < 117, `~111 m, got ${d}`);
  assert.equal(cellIdOf(center), cellIdOf({ lat: center.lat + 0.00001, lng: center.lng + 0.00001 }));
  const b = bboxAround(center, 100);
  assert.ok(b.minLat < center.lat && b.maxLng > center.lng);
});

test("clean unit goes to human review", () => {
  const o = runAutoChecks(sub(), ctx());
  assert.equal(o.status, "pending_review");
  assert.equal(level(o, "code_visible"), "manual");
});

test("random audit sends clean unit to field audit", () => {
  assert.equal(runAutoChecks(sub(), ctx({ random: () => 0.01 })).status, "field_audit");
});

test("bad GPS accuracy fails", () => {
  const o = runAutoChecks(sub({ accuracyM: 30 }), ctx());
  assert.equal(o.status, "rejected");
  assert.equal(level(o, "gps_accuracy"), "fail");
});

test("outside order area fails, edge tolerated by accuracy", () => {
  assert.equal(runAutoChecks(sub({ point: { lat: center.lat + 0.01, lng: center.lng } }), ctx()).status, "rejected");
  // ~505 m away with radius 500 and accuracy 6 m: still inside
  const edge = runAutoChecks(sub({ point: { lat: center.lat + 0.00454, lng: center.lng } }), ctx());
  assert.equal(level(edge, "inside_area"), "pass");
});

test("re-used photo fails even with a slightly different hash", () => {
  const o = runAutoChecks(sub(), ctx({ knownPhotoHashes: [{ unitId: "abc12345-x", hash: "ffff0000ffff0003" }] }));
  assert.equal(level(o, "photo_duplicate"), "fail");
  assert.equal(o.status, "rejected");
});

test("full cell blocks replication in the same area", () => {
  const o = runAutoChecks(sub(), ctx({ unitsInCell: 3 }));
  assert.equal(level(o, "cell_capacity"), "fail");
});

test("near point is only a flag (GPS noise)", () => {
  const p = sub().point;
  const o = runAutoChecks(sub(), ctx({ nearbyUnits: [{ id: "u1", point: { lat: p.lat + 0.00001, lng: p.lng }, photoHash: "0" }] }));
  assert.equal(o.status, "flagged");
});

test("undersized or wrong type fails", () => {
  assert.equal(runAutoChecks(sub({ depthCm: 20 }), ctx()).status, "rejected");
  assert.equal(runAutoChecks(sub({ structureType: "Biopori" }), ctx()).status, "rejected");
});

test("stale capture fails, offline queue flags", () => {
  const old = new Date(now.getTime() - 5 * 3_600_000);
  assert.equal(runAutoChecks(sub({ capturedAt: old }), ctx()).status, "rejected");
  assert.equal(runAutoChecks(sub({ capturedAt: old, queuedOffline: true }), ctx()).status, "flagged");
});

test("gallery upload flags", () => {
  assert.equal(runAutoChecks(sub({ liveCapture: false }), ctx()).status, "flagged");
});

test("capture before claim fails", () => {
  const o = runAutoChecks(sub({ capturedAt: new Date("2026-10-01T00:00:00Z"), receivedAt: new Date("2026-10-01T00:05:00Z") }), ctx());
  assert.equal(level(o, "claim_window"), "fail");
});

test("slots: no overselling", () => {
  const order = { quantity: 10 };
  assert.equal(freeSlots(order, [{ slots: 4, status: "active" }], 3), 3);
  assert.deepEqual(validateClaim({ slots: 4 }, 3, 0).ok, false);
  assert.deepEqual(validateClaim({ slots: 3 }, 3, 0).ok, true);
  assert.equal(validateClaim({ slots: 5 }, 10, 18).ok, false); // per-builder cap 20
});

test("rejected unit gives the slot back to its claim", () => {
  assert.equal(owedOnClaim({ slots: 3 }, [{ status: "approved" }, { status: "rejected" }]), 2);
});

test("order status derivation", () => {
  const base = { status: "open" as const, quantity: 5, expiresAt: "2027-01-01T00:00:00Z" };
  const p = { activeClaimSlots: 0, committedOutsideActive: 0, approvedTotal: 0, inReview: 0 };
  assert.equal(deriveOrderStatus(base, p, now), "open");
  assert.equal(deriveOrderStatus(base, { ...p, activeClaimSlots: 5 }, now), "in_progress");
  assert.equal(deriveOrderStatus(base, { ...p, approvedTotal: 5, committedOutsideActive: 5 }, now), "fulfilled");
  const past = { ...base, expiresAt: "2026-01-01T00:00:00Z" };
  assert.equal(deriveOrderStatus(past, p, now), "expired");
  assert.equal(deriveOrderStatus(past, { ...p, inReview: 1 }, now), "open"); // wait for review
  assert.equal(deriveOrderStatus({ ...base, status: "awaiting_payment" }, p, now), "awaiting_payment");
});

test("order code and pricing", () => {
  assert.match(makeOrderCode(), /^PA-[2-9A-HJKMNP-Z]{4}$/);
  assert.equal(orderTotalIdr(10), 100_000);
  assert.equal(platformFeeIdr(), 2_000);
  assert.equal(builderFeeIdr(), 8_000);
});

test("dHash: same photo re-encoded matches, different photo does not", async () => {
  const w = 160, h = 120;
  const a = Buffer.alloc(w * h * 3);
  const c = Buffer.alloc(w * h * 3);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 3;
      a[i] = a[i + 1] = a[i + 2] = (x * 255) / w; // left-to-right gradient
      c[i] = c[i + 1] = c[i + 2] = ((x + y) % 40) * 6; // diagonal stripes
    }
  const imgA = await sharp(a, { raw: { width: w, height: h, channels: 3 } }).jpeg({ quality: 90 }).toBuffer();
  const imgA2 = await sharp(imgA).resize(80, 60).jpeg({ quality: 40 }).toBuffer();
  const imgC = await sharp(c, { raw: { width: w, height: h, channels: 3 } }).jpeg().toBuffer();
  const [ha, ha2, hc] = await Promise.all([dHash(imgA), dHash(imgA2), dHash(imgC)]);
  assert.ok(hamming(ha, ha2) <= 6, `re-encode distance ${hamming(ha, ha2)}`);
  assert.ok(hamming(ha, hc) > 6, `different photo distance ${hamming(ha, hc)}`);
});

// ---- pricing and ID/EN ----
import { unitPriceIdr } from "../lib/pulangin/config";
import { DICTS, normalizeLang } from "../lib/pulangin/i18n";
import { toEnglish } from "../lib/pulangin/http";

test("pricing: Rp 10.000 per pit, 80% builder, 20% Jaga Semesta", () => {
  assert.equal(unitPriceIdr(), 10_000);
  assert.equal(builderFeeIdr(), 8_000);
  assert.equal(platformFeeIdr(), 2_000);
  assert.equal(builderFeeIdr() + platformFeeIdr(), unitPriceIdr());
});

test("i18n: ID and EN dictionaries have the same keys", () => {
  const keys = (o: unknown, p = ""): string[] =>
    o && typeof o === "object" && !Array.isArray(o)
      ? Object.entries(o as Record<string, unknown>).flatMap(([k, v]) => [p + k, ...keys(v, p + k + ".")])
      : [];
  assert.deepEqual(keys(DICTS.en).sort(), keys(DICTS.id).sort());
  assert.equal(DICTS.id.title, "Pulangkan Air Hujan ke Rumahnya");
  assert.equal(DICTS.en.title, "Return Water Home");
  assert.match(DICTS.en.home.lead, /infiltration pit/);
  assert.doesNotMatch(JSON.stringify(DICTS), /setiap kali/);
});

test("i18n: locale cookie values normalise", () => {
  assert.equal(normalizeLang("en"), "en");
  assert.equal(normalizeLang("en-US"), "en");
  assert.equal(normalizeLang("id"), "id");
  assert.equal(normalizeLang(undefined), "id");
});

test("i18n: every check has English detail", () => {
  const o = runAutoChecks(sub({ accuracyM: 30, liveCapture: false }), ctx({ unitsInCell: 3 }));
  for (const c of o.checks) assert.ok(c.detailEn && c.detailEn !== "", c.id);
  assert.ok(o.reasonEn && /GPS accuracy/.test(o.reasonEn));
});

test("i18n: API errors translate, including dynamic ones", () => {
  assert.equal(toEnglish("Masuk dulu"), "Please sign in first");
  assert.equal(toEnglish("Jumlah rorak 1 sampai 500"), "Between 1 and 500 pits");
  assert.equal(toEnglish("Hanya tersisa 3 slot"), "Only 3 slots left");
});
