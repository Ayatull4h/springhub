// POST /api/pulangin/iris/notify   Iris payout status callback
// The body is only used to know WHICH payout changed; the status is re-read
// from the Iris API so a forged callback can't mark money as paid.

import { db } from "@/lib/pulangin/db";
import { ok } from "@/lib/pulangin/http";
import { getPayout } from "@/lib/pulangin/midtrans";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { reference_no?: string };
  const ref = body.reference_no;
  if (!ref) return ok({ ignored: true });

  const known = await db.paUnit.count({ where: { payoutRef: ref } });
  if (!known) return ok({ ignored: true });

  const p = await getPayout(ref);
  const s = p.status.toLowerCase();
  const payoutStatus = s === "completed" ? "paid" : s === "failed" || s === "rejected" ? "failed" : "processing";
  await db.paUnit.updateMany({ where: { payoutRef: ref }, data: { payoutStatus } });
  return ok({ received: true, payoutStatus });
}
