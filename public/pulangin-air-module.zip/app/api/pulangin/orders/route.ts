// GET  /api/pulangin/orders          open orders for the job board (public)
// GET  /api/pulangin/orders?mine=1   orders I bought
// POST /api/pulangin/orders          create an order and a Midtrans Snap payment

import { PULANGIN, builderFeeIdr as builderShare, unitPriceIdr } from "@/lib/pulangin/config";
import { db, orderCounts, serializeOrder } from "@/lib/pulangin/db";
import { isInIndonesia, isValidLatLng } from "@/lib/pulangin/geo";
import { fail, int, num, ok, str } from "@/lib/pulangin/http";
import { getSessionUser, resolveSpringCenter } from "@/lib/pulangin/integration";
import { createSnapTransaction } from "@/lib/pulangin/midtrans";
import { makeOrderCode } from "@/lib/pulangin/state";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const mine = url.searchParams.get("mine") === "1";
  const user = mine ? await getSessionUser(req) : null;
  if (mine && !user) return fail(401, "Masuk dulu untuk melihat pesanan Anda");

  const rows = await db.paOrder.findMany({
    where: mine ? { buyerId: user!.id } : { status: { in: ["open", "in_progress"] } },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  const orders = await Promise.all(
    rows.map(async (o) => serializeOrder(o, await orderCounts(o.id), mine ? "owner" : "public"))
  );
  return ok({ orders });
}

export async function POST(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return fail(401, "Masuk dulu untuk memesan");

  const b = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!b) return fail(400, "Body tidak valid");

  const quantity = int(b.quantity);
  const { minQty, maxQty } = PULANGIN.pricing;
  const builderFeeIdr = builderShare();
  if (!(quantity >= minQty && quantity <= maxQty)) return fail(400, `Jumlah rorak ${minQty} sampai ${maxQty}`);

  const targetKind = str(b.targetKind, 20);
  if (!["spring", "springhub_pick", "custom_pin"].includes(targetKind)) return fail(400, "Target tidak valid");

  const springId = targetKind === "spring" ? str(b.springId, 64) || null : null;
  if (targetKind === "spring" && !springId) return fail(400, "Pilih mata air");
  const precise = springId ? await resolveSpringCenter(springId) : null;

  const center = precise ?? { lat: num(b.lat), lng: num(b.lng) };
  if (!isValidLatLng(center) || !isInIndonesia(center)) return fail(400, "Lokasi harus di Indonesia");

  const radiusM = precise
    ? PULANGIN.geo.defaultOrderRadiusM
    : Math.min(PULANGIN.geo.maxOrderRadiusM, Math.max(100, int(b.radiusM, PULANGIN.geo.defaultOrderRadiusM)));

  const fallback = b.fallback === "refund" ? "refund" : "reallocate";
  const price = unitPriceIdr();
  const grossIdr = quantity * price;

  // Retry the short code on the rare collision.
  let code = makeOrderCode();
  for (let i = 0; i < 5 && (await db.paOrder.findUnique({ where: { code } })); i++) code = makeOrderCode();

  const order = await db.paOrder.create({
    data: {
      code,
      buyerId: user.id,
      creditName: str(b.creditName, 60) || user.username,
      message: str(b.message, 280) || null,
      targetKind,
      springId,
      centerLat: center.lat,
      centerLng: center.lng,
      radiusM,
      regency: str(b.regency, 80) || null,
      province: str(b.province, 80) || null,
      quantity,
      unitPriceIdr: price,
      builderFeeIdr,
      grossIdr,
      fallback,
      status: "awaiting_payment",
    },
  });

  const midtransOrderId = `${order.code}-${Date.now().toString(36)}`;
  const site = process.env.NEXT_PUBLIC_SITE_URL ?? new URL(req.url).origin;
  const snap = await createSnapTransaction({
    midtransOrderId,
    grossIdr,
    quantity,
    unitPriceIdr: price,
    orderCode: order.code,
    customer: { firstName: user.username, email: str(b.email, 120) || null, phone: str(b.phone, 30) || null },
    finishUrl: `${site}${PULANGIN.basePath}/pesanan/${order.id}`,
  });
  await db.paOrder.update({ where: { id: order.id }, data: { midtransOrderId } });

  return ok({ orderId: order.id, code: order.code, snapToken: snap.token, redirectUrl: snap.redirect_url }, 201);
}
