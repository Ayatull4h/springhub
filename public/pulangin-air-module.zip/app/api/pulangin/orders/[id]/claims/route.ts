// POST /api/pulangin/orders/:id/claims  { slots }
// A builder reserves N rorak slots on an order for claimHoldDays.

import { db, orderProgress } from "@/lib/pulangin/db";
import { fail, int, ok } from "@/lib/pulangin/http";
import { getSessionUser } from "@/lib/pulangin/integration";
import { claimExpiry, deriveOrderStatus, freeSlots, validateClaim } from "@/lib/pulangin/state";

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const user = await getSessionUser(req);
  if (!user) return fail(401, "Masuk dulu untuk mengambil tugas");

  const payout = await db.paPayoutAccount.findUnique({ where: { builderId: user.id } });
  if (!payout?.verifiedAt) return fail(409, "Lengkapi dan verifikasi rekening pembayaran dulu");

  const body = (await req.json().catch(() => ({}))) as { slots?: unknown };
  const slots = int(body.slots);

  // Serializable transaction: two builders clicking at once can't oversell.
  try {
    const claim = await db.$transaction(
      async (tx) => {
        const order = await tx.paOrder.findUnique({ where: { id: params.id } });
        if (!order || !["open", "in_progress"].includes(order.status)) throw new Error("Pesanan tidak tersedia");
        if (order.buyerId === user.id) throw new Error("Tidak bisa mengambil pesanan sendiri");
        if (order.expiresAt && order.expiresAt < new Date()) throw new Error("Pesanan sudah lewat masa berlaku");

        const { activeClaims, progress } = await orderProgress(tx, order.id);
        const mine = await tx.paClaim.aggregate({
          where: { builderId: user.id, status: "active" },
          _sum: { slots: true },
        });
        const free = freeSlots(order, activeClaims, progress.committedOutsideActive);
        const v = validateClaim({ slots }, free, mine._sum.slots ?? 0);
        if (!v.ok) throw new Error(v.error);

        const created = await tx.paClaim.create({
          data: { orderId: order.id, builderId: user.id, slots, expiresAt: claimExpiry() },
        });
        await tx.paOrder.update({
          where: { id: order.id },
          data: {
            status: deriveOrderStatus(order, {
              ...progress,
              activeClaimSlots: progress.activeClaimSlots + slots,
            }),
          },
        });
        return created;
      },
      { isolationLevel: "Serializable" }
    );
    return ok({ claim }, 201);
  } catch (e) {
    return fail(409, e instanceof Error ? e.message : "Gagal mengambil slot");
  }
}
