// GET /api/pulangin/orders/:id
// Buyer sees delivery (photos, ~110 m points, checks). Builders with an active
// claim see the precise area. Everyone else sees the public card.

import { db, orderCounts, serializeOrder, serializeUnit, type Viewer } from "@/lib/pulangin/db";
import { fail, ok } from "@/lib/pulangin/http";
import { getSessionUser, isReviewer } from "@/lib/pulangin/integration";

export const dynamic = "force-dynamic";

export async function GET(req: Request, { params }: { params: { id: string } }) {
  const o = await db.paOrder.findUnique({ where: { id: params.id } });
  if (!o) return fail(404, "Pesanan tidak ditemukan");

  const user = await getSessionUser(req);
  let viewer: Viewer = "public";
  if (isReviewer(user)) viewer = "reviewer";
  else if (user && user.id === o.buyerId) viewer = "owner";
  else if (
    user &&
    (await db.paClaim.count({ where: { orderId: o.id, builderId: user.id, status: { in: ["active", "completed"] } } }))
  )
    viewer = "builder_claimed";

  const units = await db.paUnit.findMany({
    where:
      viewer === "owner" || viewer === "public"
        ? { orderId: o.id, status: "approved" }
        : viewer === "builder_claimed"
          ? { orderId: o.id, builderId: user!.id }
          : { orderId: o.id },
    orderBy: { capturedAt: "asc" },
  });

  return ok({
    order: serializeOrder(o, await orderCounts(o.id), viewer),
    units: units.map((u) => serializeUnit(u, viewer)),
    viewer,
  });
}
