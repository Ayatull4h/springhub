// GET /api/pulangin/claims  my active and recent claims, with precise area and progress

import { db } from "@/lib/pulangin/db";
import { fail, ok } from "@/lib/pulangin/http";
import { getSessionUser } from "@/lib/pulangin/integration";
import { owedOnClaim } from "@/lib/pulangin/state";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return fail(401, "Masuk dulu");

  const claims = await db.paClaim.findMany({
    where: { builderId: user.id },
    include: { order: true, units: { select: { id: true, status: true, payoutStatus: true, reviewNote: true } } },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  return ok({
    claims: claims.map((c) => ({
      id: c.id,
      status: c.status,
      slots: c.slots,
      owed: owedOnClaim(c, c.units),
      createdAt: c.createdAt.toISOString(),
      expiresAt: c.expiresAt.toISOString(),
      order: {
        id: c.order.id,
        code: c.order.code,
        center: { lat: c.order.centerLat, lng: c.order.centerLng }, // precise: builder holds a claim
        radiusM: c.order.radiusM,
        regency: c.order.regency,
        builderFeeIdr: c.order.builderFeeIdr,
      },
      units: c.units,
    })),
  });
}
