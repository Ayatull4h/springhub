// POST /api/pulangin/claims/:id/units   multipart/form-data, one rorak per request
// Fields: photo (file), lat, lng, accuracyM, capturedAt (ISO), liveCapture, queuedOffline,
//         structureType, shape, lengthCm, widthCm, depthCm, position, fillMaterial,
//         landownerName, landownerPhone
// Runs the automatic checks, stores the photo, creates the unit for review.

import { runAutoChecks } from "@/lib/pulangin/checks";
import { PULANGIN } from "@/lib/pulangin/config";
import { db } from "@/lib/pulangin/db";
import { bboxAround, cellIdOf, isValidLatLng } from "@/lib/pulangin/geo";
import { fail, int, num, ok, str } from "@/lib/pulangin/http";
import { LOCALE_COOKIE, normalizeLang } from "@/lib/pulangin/i18n";
import { getSessionUser, storePhoto } from "@/lib/pulangin/integration";
import { dHash } from "@/lib/pulangin/phash";
import { owedOnClaim } from "@/lib/pulangin/state";

export const runtime = "nodejs"; // sharp needs Node, not Edge

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const user = await getSessionUser(req);
  if (!user) return fail(401, "Masuk dulu");

  const claim = await db.paClaim.findUnique({
    where: { id: params.id },
    include: { order: true, units: { select: { status: true } } },
  });
  if (!claim || claim.builderId !== user.id) return fail(404, "Klaim tidak ditemukan");
  if (claim.status !== "active") return fail(409, "Klaim sudah tidak aktif");
  if (owedOnClaim(claim, claim.units) <= 0) return fail(409, "Semua slot pada klaim ini sudah dilaporkan");

  const form = await req.formData();
  const photo = form.get("photo");
  if (!(photo instanceof File)) return fail(400, "Foto rorak wajib");
  if (photo.size > PULANGIN.photo.maxBytes) return fail(413, "Foto terlalu besar");
  if (!/^image\/(jpeg|png|webp|heic|heif)$/.test(photo.type)) return fail(415, "Format foto tidak didukung");

  const point = { lat: num(form.get("lat")), lng: num(form.get("lng")) };
  if (!isValidLatLng(point)) return fail(400, "Geotag tidak valid");
  const capturedAt = new Date(str(form.get("capturedAt"), 40));
  if (Number.isNaN(capturedAt.getTime())) return fail(400, "Waktu foto tidak valid");
  const landownerName = str(form.get("landownerName"), 80);
  if (!landownerName) return fail(400, "Nama pemilik lahan wajib (izin lahan)");

  const bytes = Buffer.from(await photo.arrayBuffer());
  const photoHash = await dHash(bytes);
  const cellId = cellIdOf(point);
  const receivedAt = new Date();

  // Context for the checks. Bounding boxes keep these queries index-friendly.
  const near = bboxAround(point, PULANGIN.geo.nearDuplicateM + PULANGIN.geo.maxGpsAccuracyM);
  const wide = bboxAround(point, 2_000);
  const [nearbyUnits, unitsInCell, areaHashes, builderHashes] = await Promise.all([
    db.paUnit.findMany({
      where: {
        status: { not: "rejected" },
        lat: { gte: near.minLat, lte: near.maxLat },
        lng: { gte: near.minLng, lte: near.maxLng },
      },
      select: { id: true, lat: true, lng: true, photoHash: true },
    }),
    db.paUnit.count({ where: { cellId, status: { not: "rejected" } } }),
    db.paUnit.findMany({
      where: { lat: { gte: wide.minLat, lte: wide.maxLat }, lng: { gte: wide.minLng, lte: wide.maxLng } },
      select: { id: true, photoHash: true },
      take: 2_000,
    }),
    db.paUnit.findMany({
      where: { builderId: user.id },
      select: { id: true, photoHash: true },
      orderBy: { receivedAt: "desc" },
      take: 1_000,
    }),
  ]);

  const outcome = runAutoChecks(
    {
      point,
      accuracyM: num(form.get("accuracyM"), 999),
      capturedAt,
      receivedAt,
      liveCapture: form.get("liveCapture") === "true",
      queuedOffline: form.get("queuedOffline") === "true",
      photoHash,
      structureType: str(form.get("structureType"), 40),
      shape: str(form.get("shape"), 40),
      lengthCm: int(form.get("lengthCm"), 0),
      widthCm: int(form.get("widthCm"), 0),
      depthCm: int(form.get("depthCm"), 0),
    },
    {
      order: { center: { lat: claim.order.centerLat, lng: claim.order.centerLng }, radiusM: claim.order.radiusM },
      claim: { createdAt: claim.createdAt.toISOString(), expiresAt: claim.expiresAt.toISOString() },
      nearbyUnits: nearbyUnits.map((u) => ({ id: u.id, point: { lat: u.lat, lng: u.lng }, photoHash: u.photoHash })),
      unitsInCell,
      knownPhotoHashes: [...areaHashes, ...builderHashes].map((u) => ({ unitId: u.id, hash: u.photoHash })),
    }
  );

  const cookie = req.headers.get("cookie") ?? "";
  const lang = normalizeLang(cookie.match(new RegExp(`(?:^|; )${LOCALE_COOKIE}=([^;]+)`))?.[1]);

  const ext = photo.type.split("/")[1].replace("jpeg", "jpg");
  const photoPath = await storePhoto(
    `pulangin-air/${claim.orderId}/${receivedAt.getTime()}-${Math.random().toString(36).slice(2, 8)}.${ext}`,
    bytes,
    photo.type
  );

  const unit = await db.paUnit.create({
    data: {
      orderId: claim.orderId,
      claimId: claim.id,
      builderId: user.id,
      lat: point.lat,
      lng: point.lng,
      accuracyM: num(form.get("accuracyM"), 999),
      cellId,
      capturedAt,
      receivedAt,
      liveCapture: form.get("liveCapture") === "true",
      queuedOffline: form.get("queuedOffline") === "true",
      photoPath,
      photoHash,
      structureType: str(form.get("structureType"), 40),
      shape: str(form.get("shape"), 40),
      lengthCm: int(form.get("lengthCm"), 0),
      widthCm: int(form.get("widthCm"), 0),
      depthCm: int(form.get("depthCm"), 0),
      position: str(form.get("position"), 40) || null,
      fillMaterial: str(form.get("fillMaterial"), 40) || null,
      landownerName,
      landownerPhone: str(form.get("landownerPhone"), 30) || null,
      checks: outcome.checks,
      status: outcome.status,
      // Auto-rejection reason is stored in the builder's language.
      reviewNote: lang === "en" ? outcome.reasonEn : outcome.reason,
      reviewedAt: outcome.status === "rejected" ? receivedAt : null,
    },
  });

  return ok(
    {
      unitId: unit.id,
      status: unit.status,
      reason: outcome.reason,
      reasonEn: outcome.reasonEn,
      checks: outcome.checks,
      slaDays: PULANGIN.timing.reviewSlaDays,
    },
    201
  );
}
