// GET /api/pulangin/cron   run hourly with header  Authorization: Bearer $CRON_SECRET
// 1. Expire claims past their hold: undelivered slots go back on the board.
// 2. Expire orders past their expiry: apply the buyer's fallback.

import { db, orderProgress } from "@/lib/pulangin/db";
import { fail, ok } from "@/lib/pulangin/http";
import { deriveOrderStatus } from "@/lib/pulangin/state";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  if (!process.env.CRON_SECRET || req.headers.get("authorization") !== `Bearer ${process.env.CRON_SECRET}`) {
    return fail(401, "unauthorized");
  }
  const now = new Date();

  const staleClaims = await db.paClaim.findMany({
    where: { status: "active", expiresAt: { lt: now } },
    select: { id: true, orderId: true },
  });
  if (staleClaims.length) {
    await db.paClaim.updateMany({ where: { id: { in: staleClaims.map((c) => c.id) } }, data: { status: "expired" } });
  }

  const touched = new Set(staleClaims.map((c) => c.orderId));
  const dueOrders = await db.paOrder.findMany({
    where: { status: { in: ["open", "in_progress", "area_review"] }, expiresAt: { lt: now } },
    select: { id: true },
  });
  dueOrders.forEach((o) => touched.add(o.id));

  const expired: { id: string; fallback: string; undeliveredIdr: number }[] = [];
  for (const id of touched) {
    const order = await db.paOrder.findUniqueOrThrow({ where: { id } });
    const { progress } = await orderProgress(db, id);
    const next =
      order.status === "area_review" && order.expiresAt && order.expiresAt < now
        ? "expired"
        : deriveOrderStatus(order, progress, now);
    if (next !== order.status) {
      await db.paOrder.update({ where: { id }, data: { status: next } });
      if (next === "expired") {
        expired.push({
          id,
          fallback: order.fallback,
          undeliveredIdr: (order.quantity - progress.approvedTotal) * order.unitPriceIdr,
        });
      }
    }
  }

  // Refunds and reallocations touch money and need a human decision per
  // payment method (not every Midtrans method supports API refunds), so this
  // job reports them for the admin instead of moving funds itself.
  return ok({ claimsExpired: staleClaims.length, ordersExpired: expired });
}
