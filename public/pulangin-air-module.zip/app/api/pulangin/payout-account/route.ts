// GET/PUT /api/pulangin/payout-account   builder's bank / e-wallet for payouts
// The account is validated with Iris before it is marked verified.

import { db } from "@/lib/pulangin/db";
import { fail, ok, str } from "@/lib/pulangin/http";
import { getSessionUser } from "@/lib/pulangin/integration";
import { validateBankAccount } from "@/lib/pulangin/midtrans";

export const dynamic = "force-dynamic";

const mask = (n: string) => (n.length <= 4 ? n : "•".repeat(n.length - 4) + n.slice(-4));

export async function GET(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return fail(401, "Masuk dulu");
  const a = await db.paPayoutAccount.findUnique({ where: { builderId: user.id } });
  return ok({
    account: a && { bankCode: a.bankCode, accountNumber: mask(a.accountNumber), accountName: a.accountName, verified: !!a.verifiedAt },
  });
}

export async function PUT(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return fail(401, "Masuk dulu");
  const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const bankCode = str(b.bankCode, 30).toLowerCase();
  const accountNumber = str(b.accountNumber, 40).replace(/\D/g, "");
  if (!bankCode || accountNumber.length < 6) return fail(400, "Bank dan nomor rekening wajib");

  let accountName: string;
  try {
    accountName = (await validateBankAccount(bankCode, accountNumber)).account_name;
  } catch {
    return fail(422, "Rekening tidak dapat divalidasi. Periksa bank dan nomornya.");
  }

  await db.paPayoutAccount.upsert({
    where: { builderId: user.id },
    create: { builderId: user.id, bankCode, accountNumber, accountName, email: str(b.email, 120) || null, verifiedAt: new Date() },
    update: { bankCode, accountNumber, accountName, email: str(b.email, 120) || null, verifiedAt: new Date() },
  });
  return ok({ account: { bankCode, accountNumber: mask(accountNumber), accountName, verified: true } });
}
