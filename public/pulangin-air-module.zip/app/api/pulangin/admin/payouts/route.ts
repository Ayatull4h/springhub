// POST /api/pulangin/admin/payouts   admin only
// Groups every "queued" approved unit by builder and sends one Iris payout
// per builder. Run daily from the dashboard or a cron.

import { PULANGIN } from "@/lib/pulangin/config";
import { db } from "@/lib/pulangin/db";
import { fail, ok } from "@/lib/pulangin/http";
import { getSessionUser } from "@/lib/pulangin/integration";
import { createPayouts } from "@/lib/pulangin/midtrans";

export async function POST(req: Request) {
  const user = await getSessionUser(req);
  const cron = req.headers.get("authorization") === `Bearer ${process.env.CRON_SECRET}` && !!process.env.CRON_SECRET;
  if (!cron && user?.role !== "admin") return fail(403, "Khusus admin");

  const queued = await db.paUnit.findMany({
    where: { status: "approved", payoutStatus: "queued" },
    include: { order: { select: { code: true, builderFeeIdr: true } } },
    take: 500,
  });
  const byBuilder = new Map<string, typeof queued>();
  for (const u of queued) byBuilder.set(u.builderId, [...(byBuilder.get(u.builderId) ?? []), u]);

  const results: { builderId: string; units: number; amountIdr: number; ref?: string; error?: string }[] = [];

  for (const [builderId, units] of byBuilder) {
    const acct = await db.paPayoutAccount.findUnique({ where: { builderId } });
    const amountIdr = units.reduce((n, u) => n + u.order.builderFeeIdr, 0);
    if (!acct?.verifiedAt) {
      results.push({ builderId, units: units.length, amountIdr, error: "Rekening belum terverifikasi" });
      continue;
    }
    const ids = units.map((u) => u.id);
    // Lock first so a second run can't pay the same units twice.
    const locked = await db.paUnit.updateMany({
      where: { id: { in: ids }, payoutStatus: "queued" },
      data: { payoutStatus: "processing" },
    });
    if (locked.count !== ids.length) {
      await db.paUnit.updateMany({ where: { id: { in: ids }, payoutStatus: "processing", payoutRef: null }, data: { payoutStatus: "queued" } });
      results.push({ builderId, units: ids.length, amountIdr, error: "Bentrok dengan proses lain, coba lagi" });
      continue;
    }
    try {
      const codes = [...new Set(units.map((u) => u.order.code))].join(",");
      const res = await createPayouts([
        {
          beneficiary_name: acct.accountName,
          beneficiary_account: acct.accountNumber,
          beneficiary_bank: acct.bankCode,
          beneficiary_email: acct.email ?? undefined,
          amount: amountIdr.toFixed(2),
          notes: `Pulangkan Air Hujan ${units.length} rorak ${codes}`.slice(0, 100),
        },
      ]);
      const ref = res.payouts[0]?.reference_no;
      await db.paUnit.updateMany({ where: { id: { in: ids } }, data: { payoutRef: ref } });
      results.push({ builderId, units: ids.length, amountIdr, ref });
    } catch (e) {
      await db.paUnit.updateMany({ where: { id: { in: ids } }, data: { payoutStatus: "queued" } });
      results.push({ builderId, units: ids.length, amountIdr, error: e instanceof Error ? e.message : "Iris error" });
    }
  }

  return ok({ basePath: PULANGIN.basePath, batches: results });
}
