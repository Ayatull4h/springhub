// POST /api/pulangin/admin/units/:id   { action: "approve" | "reject" | "field_audit", note? }
// Approve = rorak delivered: queue the builder payout, mirror into live reports
// (map, dashboard, +500 points), update claim and order progress.

import { db, orderProgress } from "@/lib/pulangin/db";
import { fail, ok, str } from "@/lib/pulangin/http";
import { getSessionUser, isReviewer, mirrorToLiveReports, toLiveTrenchReport } from "@/lib/pulangin/integration";
import { deriveOrderStatus, owedOnClaim } from "@/lib/pulangin/state";

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const user = await getSessionUser(req);
  if (!isReviewer(user)) return fail(403, "Khusus admin / field lead");

  const b = (await req.json().catch(() => ({}))) as { action?: string; note?: unknown };
  const action = b.action;
  const note = str(b.note, 500) || null;
  if (!["approve", "reject", "field_audit"].includes(action ?? "")) return fail(400, "Aksi tidak valid");
  if (action === "reject" && !note) return fail(400, "Alasan penolakan wajib diisi (dikirim ke pembuat)");

  const unit = await db.paUnit.findUnique({ where: { id: params.id }, include: { order: true } });
  if (!unit) return fail(404, "Unit tidak ditemukan");
  if (unit.status === "approved" || unit.status === "rejected") return fail(409, "Unit sudah diputuskan");
  if (unit.builderId === user!.id) return fail(403, "Tidak boleh memverifikasi rorak sendiri");

  if (action === "field_audit") {
    await db.paUnit.update({ where: { id: unit.id }, data: { status: "field_audit", reviewNote: note } });
    return ok({ status: "field_audit" });
  }

  const approve = action === "approve";
  await db.$transaction(async (tx) => {
    await tx.paUnit.update({
      where: { id: unit.id },
      data: {
        status: approve ? "approved" : "rejected",
        reviewerId: user!.id,
        reviewNote: note,
        reviewedAt: new Date(),
        payoutStatus: approve ? "queued" : "none",
      },
    });

    // Claim completes when every slot has an approved unit.
    const claim = await tx.paClaim.findUniqueOrThrow({
      where: { id: unit.claimId },
      include: { units: { select: { status: true } } },
    });
    const allApproved = claim.units.filter((u) => u.status === "approved").length >= claim.slots;
    if (claim.status === "active" && allApproved && owedOnClaim(claim, claim.units) === 0) {
      await tx.paClaim.update({ where: { id: claim.id }, data: { status: "completed" } });
    }

    const order = await tx.paOrder.findUniqueOrThrow({ where: { id: unit.orderId } });
    const { progress } = await orderProgress(tx, order.id);
    await tx.paOrder.update({ where: { id: order.id }, data: { status: deriveOrderStatus(order, progress) } });
  });

  if (approve) {
    // Outside the transaction: a failure here must not undo the approval.
    const reportId = await mirrorToLiveReports(
      toLiveTrenchReport({
        builderName: unit.builderId, // TODO(repo owner): resolve the builder's display name
        builderPhone: null,
        orderCode: unit.order.code,
        springCode: unit.order.springId,
        capturedAt: unit.capturedAt,
        lat: unit.lat,
        lng: unit.lng,
        accuracyM: unit.accuracyM,
        structureType: unit.structureType,
        shape: unit.shape,
        lengthCm: unit.lengthCm,
        widthCm: unit.widthCm,
        depthCm: unit.depthCm,
        position: unit.position,
        fillMaterial: unit.fillMaterial,
        photoPath: unit.photoPath,
      })
    ).catch(() => null);
    if (reportId) await db.paUnit.update({ where: { id: unit.id }, data: { reportId } });
  }

  return ok({ status: approve ? "approved" : "rejected" });
}
