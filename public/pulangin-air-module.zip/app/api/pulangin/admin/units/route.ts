// GET /api/pulangin/admin/units?status=flagged   review queue (admin / field_lead)

import { db, serializeUnit } from "@/lib/pulangin/db";
import { fail, ok } from "@/lib/pulangin/http";
import { getSessionUser, isReviewer } from "@/lib/pulangin/integration";

export const dynamic = "force-dynamic";

const QUEUE = ["flagged", "field_audit", "pending_review"] as const;

export async function GET(req: Request) {
  const user = await getSessionUser(req);
  if (!isReviewer(user)) return fail(403, "Khusus admin / field lead");

  const s = new URL(req.url).searchParams.get("status");
  const statuses = s && (QUEUE as readonly string[]).includes(s) ? [s as (typeof QUEUE)[number]] : [...QUEUE];

  const units = await db.paUnit.findMany({
    where: { status: { in: statuses } },
    include: { order: { select: { code: true, regency: true } } },
    orderBy: { receivedAt: "asc" }, // oldest first, protects the SLA
    take: 100,
  });
  return ok({
    units: units.map((u) => ({ ...serializeUnit(u, "reviewer"), orderCode: u.order.code, regency: u.order.regency })),
  });
}
