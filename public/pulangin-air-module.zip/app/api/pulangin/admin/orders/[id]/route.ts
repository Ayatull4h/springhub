// POST /api/pulangin/admin/orders/:id   { action: "open_area", radiusM?, lat?, lng? }
// Field lead confirms a buyer-chosen site (land consent possible, slope safe,
// inside a recharge area) and may tighten the area before it goes public.

import { PULANGIN } from "@/lib/pulangin/config";
import { db } from "@/lib/pulangin/db";
import { isInIndonesia, isValidLatLng } from "@/lib/pulangin/geo";
import { fail, int, num, ok } from "@/lib/pulangin/http";
import { getSessionUser, isReviewer } from "@/lib/pulangin/integration";

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const user = await getSessionUser(req);
  if (!isReviewer(user)) return fail(403, "Khusus admin / field lead");

  const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  if (b.action !== "open_area") return fail(400, "Aksi tidak valid");

  const order = await db.paOrder.findUnique({ where: { id: params.id } });
  if (!order || order.status !== "area_review") return fail(409, "Pesanan tidak menunggu tinjauan area");

  const moved = { lat: num(b.lat, order.centerLat), lng: num(b.lng, order.centerLng) };
  if (!isValidLatLng(moved) || !isInIndonesia(moved)) return fail(400, "Lokasi tidak valid");
  const radiusM = Math.min(PULANGIN.geo.maxOrderRadiusM, Math.max(100, int(b.radiusM, order.radiusM)));

  await db.paOrder.update({
    where: { id: order.id },
    data: { status: "open", centerLat: moved.lat, centerLng: moved.lng, radiusM },
  });
  return ok({ status: "open" });
}
