// POST /api/pulangin/midtrans/notify   Midtrans Snap HTTP notification
// Set this URL in the Midtrans dashboard, or route Pulangkan Air Hujan order ids
// (prefix "PA-") here from the existing donation webhook if Midtrans only
// allows one notification URL per merchant.

import { db } from "@/lib/pulangin/db";
import { fail, ok } from "@/lib/pulangin/http";
import { getTransactionStatus, mapTransactionStatus, verifySnapSignature } from "@/lib/pulangin/midtrans";
import { orderExpiry } from "@/lib/pulangin/state";

export async function POST(req: Request) {
  const n = (await req.json().catch(() => null)) as {
    order_id: string;
    status_code: string;
    gross_amount: string;
    signature_key: string;
  } | null;
  if (!n || !verifySnapSignature(n)) return fail(401, "invalid signature");

  const order = await db.paOrder.findUnique({ where: { midtransOrderId: n.order_id } });
  if (!order) return ok({ ignored: true }); // not a Pulangkan Air Hujan payment

  // Source of truth is the status API, not the webhook body.
  const status = await getTransactionStatus(n.order_id);
  if (Math.round(Number(status.gross_amount)) !== order.grossIdr) return fail(400, "amount mismatch");
  const outcome = mapTransactionStatus(status);

  if (outcome === "paid" && order.status === "awaiting_payment") {
    const paidAt = new Date();
    await db.paOrder.update({
      where: { id: order.id },
      data: {
        paidAt,
        expiresAt: orderExpiry(paidAt),
        // A buyer-chosen pin needs a field lead to confirm land and slope first.
        status: order.targetKind === "custom_pin" ? "area_review" : "open",
      },
    });
  } else if (outcome === "failed" && order.status === "awaiting_payment") {
    await db.paOrder.update({ where: { id: order.id }, data: { status: "cancelled" } });
  }
  // "refunded" is recorded by the expiry job that issued the refund.

  return ok({ received: true });
}
