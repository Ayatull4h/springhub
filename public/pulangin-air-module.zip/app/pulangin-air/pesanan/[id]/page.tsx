"use client";

// Buyer's "delivery" page: like tracking a parcel, but the parcel is a set of
// verified infiltration pits with photos and (coarsened) geotags.

import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import { CalendarDays, Ruler } from "lucide-react";
import { useT } from "@/components/pulangin/lang";
import { OrderBadge, Progress, UnitBadge, api, photoUrl, rupiah } from "@/components/pulangin/ui";
import type { Order, RorakUnit } from "@/lib/pulangin/types";

const AreaMap = dynamic(() => import("@/components/pulangin/area-map"), { ssr: false });

export default function OrderDetail({ params }: { params: { id: string } }) {
  const t = useT();
  const [data, setData] = useState<{ order: Order; units: RorakUnit[]; viewer: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<{ order: Order; units: RorakUnit[]; viewer: string }>(`/api/pulangin/orders/${params.id}`)
      .then(setData)
      .catch((e: Error) => setError(e.message));
  }, [params.id]);

  if (error) return <p className="container-page py-10 text-ink-muted">{error}</p>;
  if (!data) return <p className="container-page py-10 text-ink-muted">{t.loading}</p>;
  const { order: o, units } = data;
  const approved = units.filter((u) => u.status === "approved");

  return (
    <div className="container-page space-y-6 py-10">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="font-mono text-xs text-ink-subtle">{o.code}</p>
          <h1 className="text-2xl font-extrabold text-ink">
            {t.units(o.quantity)} · {o.regency ?? t.card.pickedBySpringhub}
          </h1>
          {o.grossIdr > 0 && <p className="text-sm text-ink-muted">{t.detail.paid(rupiah(o.grossIdr))}</p>}
        </div>
        <OrderBadge status={o.status} />
      </header>

      {o.status === "awaiting_payment" && <p className="card text-sm text-ink-muted">{t.detail.awaiting}</p>}
      {o.status === "area_review" && <p className="card text-sm text-ink-muted">{t.detail.areaReview}</p>}

      <div className="card space-y-4">
        <Progress done={o.unitsApproved} total={o.quantity} />
        <AreaMap
          center={o.center}
          radiusM={o.radiusM}
          points={approved.map((u, i) => ({ id: u.id, point: u.point, label: t.detail.unitN(i + 1) }))}
          height={300}
        />
        <p className="text-xs text-ink-subtle">{t.detail.precision}</p>
      </div>

      <section>
        <h2 className="text-lg font-bold text-ink">{t.detail.reports(approved.length)}</h2>
        <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {approved.length === 0 && <p className="text-sm text-ink-muted">{t.detail.none}</p>}
          {approved.map((u, i) => (
            <figure key={u.id} className="card overflow-hidden p-0">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={photoUrl(u.photoPath)} alt={t.detail.unitN(i + 1)} className="aspect-[4/3] w-full object-cover" loading="lazy" />
              <figcaption className="space-y-1 p-4 text-sm">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-ink">{t.detail.unitN(i + 1)}</span>
                  <UnitBadge status={u.status} />
                </div>
                <p className="flex items-center gap-1 text-ink-muted">
                  <Ruler className="h-3.5 w-3.5" /> {u.lengthCm} × {u.widthCm} × {u.depthCm} cm
                </p>
                <p className="flex items-center gap-1 text-ink-muted">
                  <CalendarDays className="h-3.5 w-3.5" /> {new Date(u.capturedAt).toLocaleDateString(t.locale, { dateStyle: "medium" })}
                </p>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>
    </div>
  );
}
