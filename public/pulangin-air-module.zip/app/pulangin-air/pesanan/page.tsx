"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useT } from "@/components/pulangin/lang";
import { OrderCard } from "@/components/pulangin/open-orders";
import { api } from "@/components/pulangin/ui";
import type { Order } from "@/lib/pulangin/types";

export default function MyOrders() {
  const t = useT();
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    api<{ orders: Order[] }>("/api/pulangin/orders?mine=1")
      .then((r) => setOrders(r.orders))
      .catch((e: Error) => setError(e.message));
  }, []);

  return (
    <div className="container-page py-10">
      <h1 className="text-2xl font-extrabold text-ink">{t.mine.heading}</h1>
      {error && (
        <p className="mt-4 text-sm text-ink-muted">
          {error}.{" "}
          <Link href="/sign-in" className="text-sky-500 underline">
            {t.signIn}
          </Link>
        </p>
      )}
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {orders?.length === 0 && (
          <p className="text-sm text-ink-muted">
            {t.mine.empty}{" "}
            <Link href="/pulangin-air/pesan" className="text-sky-500 underline">
              {t.mine.first}
            </Link>
          </p>
        )}
        {orders?.map((o) => <OrderCard key={o.id} o={o} />)}
      </div>
    </div>
  );
}
