"use client";

import dynamic from "next/dynamic";
import { useEffect, useMemo, useState } from "react";
import { HandCoins } from "lucide-react";
import { useT } from "@/components/pulangin/lang";
import { Field, api, cx, rupiah } from "@/components/pulangin/ui";
import { PULANGIN, builderFeeIdr, orderTotalIdr, platformFeeIdr } from "@/lib/pulangin/config";
import type { LatLng } from "@/lib/pulangin/types";

const AreaMap = dynamic(() => import("@/components/pulangin/area-map"), { ssr: false });

type Spring = { id: string; name: string; point: LatLng; regency: string | null };
type TargetKind = "springhub_pick" | "spring" | "custom_pin";

/** Tolerant mapper for the live /api/springs shape (public, 5 km snapped). */
function toSpring(s: Record<string, unknown>): Spring | null {
  const lat = Number(s.snappedLat ?? s.publicLat ?? s.lat ?? s.latitude);
  const lng = Number(s.snappedLng ?? s.publicLng ?? s.lng ?? s.longitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  return {
    id: String(s.id),
    name: String(s.name ?? s.title ?? "Mata air"),
    point: { lat, lng },
    regency: (s.regency ?? s.region ?? null) as string | null,
  };
}

// Default priority catchment until SpringHub publishes its own list.
const SPRINGHUB_PICK = { lat: -7.7956, lng: 110.3695 };

export default function OrderPage() {
  const t = useT();
  const o = t.order;
  const [kind, setKind] = useState<TargetKind>("springhub_pick");
  const [springs, setSprings] = useState<Spring[]>([]);
  const [springId, setSpringId] = useState("");
  const [pin, setPin] = useState<LatLng | null>(null);
  const [regency, setRegency] = useState("");
  const [qty, setQty] = useState(10);
  const [creditName, setCreditName] = useState("");
  const [message, setMessage] = useState("");
  const [email, setEmail] = useState("");
  const [fallback, setFallback] = useState<"reallocate" | "refund">("reallocate");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<Record<string, unknown>>("/api/springs")
      .then((r) => {
        const list = (Object.values(r).find(Array.isArray) ?? []) as Record<string, unknown>[];
        setSprings(list.map(toSpring).filter((s): s is Spring => !!s));
      })
      .catch(() => setSprings([]));
  }, []);

  const spring = springs.find((s) => s.id === springId);
  const center: LatLng | null = kind === "spring" ? spring?.point ?? null : kind === "custom_pin" ? pin : SPRINGHUB_PICK;
  // Spring points are public (5 km snapped), so the area must cover that cell
  // until resolveSpringCenter() returns the precise point server-side.
  const radiusM = kind === "spring" ? 3_000 : kind === "custom_pin" ? 500 : 5_000;
  const total = useMemo(() => orderTotalIdr(qty), [qty]);
  const { minQty, maxQty, showFeeBreakdown } = PULANGIN.pricing;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!center) return setError(o.needLocation);
    setBusy(true);
    setError(null);
    try {
      const r = await api<{ redirectUrl: string }>("/api/pulangin/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetKind: kind,
          springId: kind === "spring" ? springId : undefined,
          lat: center.lat,
          lng: center.lng,
          radiusM,
          regency: kind === "spring" ? spring?.regency : kind === "custom_pin" ? regency : o.pickedRegency,
          quantity: qty,
          creditName,
          message,
          email,
          fallback,
        }),
      });
      window.location.href = r.redirectUrl; // Midtrans Snap hosted page
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="container-page grid gap-6 py-10 lg:grid-cols-[1fr_360px]">
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-extrabold text-ink md:text-3xl">{o.heading}</h1>
          <p className="mt-1 text-sm text-ink-muted">{o.sub}</p>
        </div>

        <fieldset className="card space-y-4">
          <legend className="sr-only">{o.step1}</legend>
          <p className="text-sm font-semibold text-ink">{o.step1}</p>
          <div className="grid gap-2 sm:grid-cols-3">
            {(["springhub_pick", "spring", "custom_pin"] as const).map((k) => (
              <button
                type="button"
                key={k}
                onClick={() => setKind(k)}
                aria-pressed={kind === k}
                className={cx(
                  "rounded-lg border p-3 text-left transition",
                  kind === k ? "border-sky-500 bg-sky-500/10" : "border-ink-line hover:border-sky-500/50"
                )}
              >
                <span className="block text-sm font-semibold text-ink">{o.targets[k][0]}</span>
                <span className="block text-xs text-ink-muted">{o.targets[k][1]}</span>
              </button>
            ))}
          </div>

          {kind === "spring" && (
            <Field label={o.spring}>
              <select className="input mt-1 w-full" value={springId} onChange={(e) => setSpringId(e.target.value)} required>
                <option value="">{o.pickSpring}</option>
                {springs.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                    {s.regency ? ` · ${s.regency}` : ""}
                  </option>
                ))}
              </select>
            </Field>
          )}
          {kind === "custom_pin" && (
            <>
              <Field label={o.regency}>
                <input className="input mt-1 w-full" value={regency} onChange={(e) => setRegency(e.target.value)} required />
              </Field>
              <p className="text-xs text-ink-muted">{o.pinHint}</p>
            </>
          )}
          <AreaMap center={center} radiusM={radiusM} onPick={kind === "custom_pin" ? setPin : undefined} height={280} />
        </fieldset>

        <fieldset className="card space-y-4">
          <legend className="sr-only">{o.step2}</legend>
          <p className="text-sm font-semibold text-ink">{o.step2}</p>
          <div className="flex flex-wrap gap-2">
            {[5, 10, 25, 50, 100].map((n) => (
              <button
                type="button"
                key={n}
                onClick={() => setQty(n)}
                aria-pressed={qty === n}
                className={cx("chip border", qty === n ? "border-sky-500 bg-sky-500/10 text-sky-500" : "border-ink-line text-ink-muted")}
              >
                {n}
              </button>
            ))}
            <input
              type="number"
              min={minQty}
              max={maxQty}
              value={qty}
              onChange={(e) => setQty(Math.max(minQty, Math.min(maxQty, Number(e.target.value) || minQty)))}
              className="input w-24"
              aria-label={o.qtyLabel}
            />
          </div>
          <Field label={o.credit} hint={o.creditHint}>
            <input className="input mt-1 w-full" value={creditName} onChange={(e) => setCreditName(e.target.value)} maxLength={60} />
          </Field>
          <Field label={o.message}>
            <textarea className="input mt-1 w-full" rows={2} value={message} onChange={(e) => setMessage(e.target.value)} maxLength={280} />
          </Field>
          <Field label={o.email}>
            <input type="email" className="input mt-1 w-full" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label={o.fallback}>
            <select className="input mt-1 w-full" value={fallback} onChange={(e) => setFallback(e.target.value as typeof fallback)}>
              <option value="reallocate">{o.fallbackReallocate}</option>
              <option value="refund">{o.fallbackRefund}</option>
            </select>
          </Field>
        </fieldset>
      </div>

      <aside className="card h-fit space-y-3 lg:sticky lg:top-24">
        <h2 className="font-semibold text-ink">{o.summary}</h2>
        <dl className="space-y-1 text-sm">
          <div className="flex justify-between text-ink-muted">
            <dt>
              {t.units(qty)} × {rupiah(PULANGIN.pricing.unitPriceIdr)}
            </dt>
            <dd>{rupiah(total)}</dd>
          </div>
          {showFeeBreakdown && (
            <>
              <div className="flex justify-between gap-3 text-xs text-ink-subtle">
                <dt>{o.lineBuilder}</dt>
                <dd className="shrink-0">{rupiah(qty * builderFeeIdr())}</dd>
              </div>
              <div className="flex justify-between gap-3 text-xs text-ink-subtle">
                <dt>{o.linePlatform}</dt>
                <dd className="shrink-0">{rupiah(qty * platformFeeIdr())}</dd>
              </div>
            </>
          )}
          <div className="flex justify-between border-t border-ink-line pt-2 text-base font-bold text-ink">
            <dt>{o.total}</dt>
            <dd>{rupiah(total)}</dd>
          </div>
        </dl>
        {error && (
          <p className="text-sm text-rose-500" role="alert">
            {error}
          </p>
        )}
        <button className="btn-primary w-full" disabled={busy || !center}>
          <HandCoins className="h-4 w-4" /> {busy ? o.paying : o.pay}
        </button>
        <p className="text-xs text-ink-subtle">{o.methods}</p>
      </aside>
    </form>
  );
}
