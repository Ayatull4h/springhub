"use client";

import Link from "next/link";
import { CheckCircle2, Droplets, HandCoins, Shovel, ShieldCheck } from "lucide-react";
import { useT } from "@/components/pulangin/lang";
import { OrderCard, useOpenOrders } from "@/components/pulangin/open-orders";
import { PULANGIN } from "@/lib/pulangin/config";

export default function PulanginHome() {
  const t = useT();
  const { orders } = useOpenOrders();
  const h = t.home;

  return (
    <div className="container-page space-y-14 py-10">
      <section className="grid items-center gap-8 md:grid-cols-[1.2fr_1fr]">
        <div>
          <p className="chip bg-sky-500/15 text-sky-500">
            <Droplets className="h-3.5 w-3.5" /> {t.tagline}
          </p>
          <h1 className="mt-4 text-3xl font-extrabold tracking-tight text-ink md:text-5xl">{t.title}</h1>
          <p className="mt-4 max-w-xl text-ink-muted">{h.lead}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/pulangin-air/pesan" className="btn-primary">
              <HandCoins className="h-4 w-4" /> {h.ctaOrder}
            </Link>
            <Link href="/pulangin-air/tugas" className="btn-secondary">
              <Shovel className="h-4 w-4" /> {h.ctaBuild}
            </Link>
          </div>
          <p className="mt-3 max-w-xl text-xs text-ink-subtle">{h.priceNote}</p>
        </div>
        <div className="card space-y-3">
          <h2 className="text-sm font-semibold text-ink">{h.specTitle}</h2>
          <dl className="grid grid-cols-3 gap-2 text-center">
            {(
              [
                [h.specL, PULANGIN.spec.minLengthCm],
                [h.specW, PULANGIN.spec.minWidthCm],
                [h.specD, PULANGIN.spec.minDepthCm],
              ] as const
            ).map(([k, v]) => (
              <div key={k} className="rounded-lg border border-ink-line p-3">
                <dt className="text-xs text-ink-muted">{k}</dt>
                <dd className="text-xl font-bold text-ink">
                  {v}
                  <span className="text-xs font-normal"> cm</span>
                </dd>
              </div>
            ))}
          </dl>
          <p className="text-xs text-ink-muted">{h.specNote}</p>
        </div>
      </section>

      <section className="grid gap-6 md:grid-cols-2">
        {[
          { title: h.forBuyer, icon: HandCoins, steps: h.buyerSteps },
          { title: h.forBuilder, icon: Shovel, steps: h.builderSteps },
        ].map(({ title, icon: Icon, steps }) => (
          <div key={title} className="card">
            <h2 className="flex items-center gap-2 font-semibold text-ink">
              <Icon className="h-5 w-5 text-sky-500" /> {title}
            </h2>
            <ol className="mt-4 space-y-4">
              {steps.map(([head, body], i) => (
                <li key={head} className="flex gap-3">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-sky-500/15 text-sm font-bold text-sky-500">
                    {i + 1}
                  </span>
                  <div>
                    <p className="font-medium text-ink">{head}</p>
                    <p className="text-sm text-ink-muted">{body}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        ))}
      </section>

      <section className="card">
        <h2 className="flex items-center gap-2 font-semibold text-ink">
          <ShieldCheck className="h-5 w-5 text-emerald-500" /> {h.trustTitle}
        </h2>
        <ul className="mt-4 grid gap-3 text-sm text-ink-muted sm:grid-cols-2">
          {h.trust.map((line) => (
            <li key={line} className="flex gap-2">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" /> {line}
            </li>
          ))}
        </ul>
      </section>

      <section>
        <div className="flex items-end justify-between">
          <h2 className="text-xl font-bold text-ink">{h.openTitle}</h2>
          <Link href="/pulangin-air/tugas" className="text-sm font-semibold text-emerald-500">
            {h.allTasks}
          </Link>
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {orders === null && <p className="text-sm text-ink-muted">{t.loading}</p>}
          {orders?.length === 0 && <p className="text-sm text-ink-muted">{h.noOpen}</p>}
          {orders?.slice(0, 6).map((o) => <OrderCard key={o.id} o={o} />)}
        </div>
      </section>
    </div>
  );
}
