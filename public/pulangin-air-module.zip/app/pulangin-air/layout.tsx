import type { Metadata } from "next";
import { cookies } from "next/headers";
import { LangProvider, SubNav } from "@/components/pulangin/lang";
import { LOCALE_COOKIE, normalizeLang } from "@/lib/pulangin/i18n";

export async function generateMetadata(): Promise<Metadata> {
  const lang = normalizeLang(cookies().get(LOCALE_COOKIE)?.value);
  return lang === "en"
    ? {
        title: "Return Water Home · SpringHub",
        description: "Fund infiltration pits dug by local people, each verified with a geotagged photo.",
        openGraph: { title: "Return Water Home · SpringHub", description: "Fund infiltration pits dug by local people, each verified with a geotagged photo." },
      }
    : {
        title: "Pulangkan Air Hujan ke Rumahnya · SpringHub",
        description: "Pesan rorak untuk memulangkan air hujan ke tanah, atau dapatkan bayaran dengan membuatnya. Setiap rorak dilaporkan dengan foto dan geotag.",
        openGraph: { title: "Pulangkan Air Hujan ke Rumahnya · SpringHub", description: "Pesan rorak, dibuat warga, dibuktikan dengan foto dan geotag." },
      };
}

export default function PulanginLayout({ children }: { children: React.ReactNode }) {
  const lang = normalizeLang(cookies().get(LOCALE_COOKIE)?.value);
  return (
    <LangProvider lang={lang}>
      <SubNav />
      <div lang={lang}>{children}</div>
    </LangProvider>
  );
}
