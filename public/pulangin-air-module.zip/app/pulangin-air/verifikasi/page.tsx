"use client";

// Reviewer queue for admins and field leads. Oldest first (protects the SLA).
// Not linked from the public sub-nav; add it to the existing admin menu.

import { useEffect, useState } from "react";
import { Check, MapPinned, X } from "lucide-react";
import { useT } from "@/components/pulangin/lang";
import { UnitBadge, api, checkText, cx, photoUrl } from "@/components/pulangin/ui";
import type { RorakUnit } from "@/lib/pulangin/types";

type QueueUnit = RorakUnit & { orderCode: string; regency: string | null };

export default function ReviewQueue() {
  const t = useT();
  const v = t.review;
  const [units, setUnits] = useState<QueueUnit[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [payoutMsg, setPayoutMsg] = useState<string | null>(null);

  const load = () =>
    api<{ units: QueueUnit[] }>("/api/pulangin/admin/units")
      .then((r) => setUnits(r.units))
      .catch((e: Error) => setError(e.message));
  useEffect(() => {
    void load();
  }, []);

  async function decide(id: string, action: "approve" | "reject" | "field_audit") {
    try {
      await api(`/api/pulangin/admin/units/${id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, note: notes[id] }),
      });
      if (action === "field_audit") void load();
      else setUnits((u) => u?.filter((x) => x.id !== id) ?? null);
    } catch (e) {
      setNotes((n) => ({ ...n, [id]: `⚠ ${(e as Error).message}` }));
    }
  }

  async function runPayouts() {
    setPayoutMsg(v.processing);
    try {
      const r = await api<{ batches: { units: number; amountIdr: number; error?: string }[] }>("/api/pulangin/admin/payouts", { method: "POST" });
      const ok = r.batches.filter((b) => !b.error);
      setPayoutMsg(v.payoutResult(ok.length, ok.reduce((n, b) => n + b.units, 0), r.batches.length - ok.length));
    } catch (e) {
      setPayoutMsg((e as Error).message);
    }
  }

  if (error) return <p className="container-page py-10 text-ink-muted">{error}</p>;

  return (
    <div className="container-page space-y-6 py-10">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-ink">{v.heading}</h1>
          <p className="text-sm text-ink-muted">{v.sub}</p>
        </div>
        <div className="text-right">
          <button type="button" className="btn-secondary" onClick={runPayouts}>
            {v.runPayouts}
          </button>
          {payoutMsg && <p className="mt-1 text-xs text-ink-muted">{payoutMsg}</p>}
        </div>
      </header>

      {units === null && <p className="text-ink-muted">{t.loading}</p>}
      {units?.length === 0 && <p className="text-ink-muted">{v.empty}</p>}

      <div className="grid gap-4 lg:grid-cols-2">
        {units?.map((u) => (
          <article key={u.id} className={cx("card grid gap-4 sm:grid-cols-[200px_1fr]", u.status === "flagged" && "border-amber-500/50")}>
            <a href={photoUrl(u.photoPath)} target="_blank" rel="noreferrer">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={photoUrl(u.photoPath)} alt={t.capture.photoAlt} className="aspect-[4/3] w-full rounded-lg object-cover" />
            </a>
            <div className="space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs text-ink-subtle">
                  {u.orderCode} · {u.regency}
                </span>
                <UnitBadge status={u.status} />
              </div>
              <p className="text-ink">
                {t.report.types[u.structureType] ?? u.structureType} {u.lengthCm}×{u.widthCm}×{u.depthCm} cm ·{" "}
                {u.position ? t.report.positions[u.position] ?? u.position : ""} · {v.owner}: {u.landownerName}
                {u.landownerPhone ? ` (${u.landownerPhone})` : ""}
              </p>
              <a
                className="inline-flex items-center gap-1 text-xs text-sky-500 underline"
                href={`https://www.openstreetmap.org/?mlat=${u.point.lat}&mlon=${u.point.lng}#map=18/${u.point.lat}/${u.point.lng}`}
                target="_blank"
                rel="noreferrer"
              >
                <MapPinned className="h-3.5 w-3.5" /> {u.point.lat.toFixed(5)}, {u.point.lng.toFixed(5)} ±{Math.round(u.accuracyM)} m
              </a>
              <ul className="space-y-0.5 text-xs">
                {u.checks.map((c) => (
                  <li key={c.id} className={c.level === "flag" ? "text-amber-500" : c.level === "manual" ? "text-sky-500" : "text-ink-muted"}>
                    {c.level === "pass" ? "✓" : c.level === "flag" ? "!" : "?"} {checkText(c, t.lang)}
                  </li>
                ))}
              </ul>
              <input
                className="input w-full py-1.5 text-xs"
                placeholder={v.note}
                aria-label={v.note}
                value={notes[u.id] ?? ""}
                onChange={(e) => setNotes({ ...notes, [u.id]: e.target.value })}
              />
              <div className="flex flex-wrap gap-2">
                <button type="button" className="btn-primary bg-emerald-600 px-3 py-1.5 hover:bg-emerald-700" onClick={() => decide(u.id, "approve")}>
                  <Check className="h-4 w-4" /> {v.approve}
                </button>
                <button type="button" className="btn-secondary px-3 py-1.5" onClick={() => decide(u.id, "reject")}>
                  <X className="h-4 w-4" /> {v.reject}
                </button>
                {u.status !== "field_audit" && (
                  <button type="button" className="btn-ghost px-3 py-1.5" onClick={() => decide(u.id, "field_audit")}>
                    {v.audit}
                  </button>
                )}
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
