"use client";

// Builder delivery report: one pit per submit. Option VALUES stay identical to
// the live "trench-development" form (Indonesian) so data maps 1:1 into
// /api/reports; only the visible labels are translated.

import dynamic from "next/dynamic";
import Link from "next/link";
import { useEffect, useState } from "react";
import { ArrowLeft, Send } from "lucide-react";
import { useT } from "@/components/pulangin/lang";
import { LiveCapture, type Capture } from "@/components/pulangin/live-capture";
import { Field, api, checkText, cx } from "@/components/pulangin/ui";
import { PULANGIN } from "@/lib/pulangin/config";
import type { CheckResult } from "@/lib/pulangin/types";

const AreaMap = dynamic(() => import("@/components/pulangin/area-map"), { ssr: false });

type ClaimView = {
  id: string;
  owed: number;
  slots: number;
  order: { id: string; code: string; center: { lat: number; lng: number }; radiusM: number; regency: string | null };
};

const POSITIONS = ["Area Resapan", "Pinggir Jalan", "Di Antara Tanaman", "Lereng", "Lainnya"];
const FILLS = ["Kosong", "Batu", "Ijuk", "Daun/Seresah", "Kompos", "Lainnya"];

type Result = { status: string; reason: string | null; reasonEn: string | null; checks: CheckResult[] };

export default function ReportUnit({ params }: { params: { claimId: string } }) {
  const t = useT();
  const r = t.report;
  const [claim, setClaim] = useState<ClaimView | null>(null);
  const [cap, setCap] = useState<Capture | null>(null);
  const [f, setF] = useState({
    structureType: "Rorak",
    shape: "Kotak",
    lengthCm: "",
    widthCm: "",
    depthCm: "",
    position: "Area Resapan",
    fillMaterial: "Kosong",
    landownerName: "",
    landownerPhone: "",
    consent: false,
  });
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = () =>
    api<{ claims: ClaimView[] }>("/api/pulangin/claims").then((res) => setClaim(res.claims.find((c) => c.id === params.claimId) ?? null));
  useEffect(() => {
    void load();
  }, [params.claimId]);

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setF({ ...f, [k]: e.target.type === "checkbox" ? (e.target as HTMLInputElement).checked : e.target.value });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!cap || !claim) return;
    setBusy(true);
    setError(null);
    const fd = new FormData();
    fd.append("photo", cap.blob, `rorak-${Date.now()}.jpg`);
    fd.append("lat", String(cap.point.lat));
    fd.append("lng", String(cap.point.lng));
    fd.append("accuracyM", String(cap.accuracyM));
    fd.append("capturedAt", cap.capturedAt.toISOString());
    fd.append("liveCapture", String(cap.liveCapture));
    fd.append("queuedOffline", "false"); // TODO: set true when sent from the live offline queue
    for (const k of ["structureType", "shape", "lengthCm", "widthCm", "depthCm", "position", "fillMaterial", "landownerName", "landownerPhone"] as const) {
      fd.append(k, String(f[k]));
    }
    try {
      const res = await api<Result>(`/api/pulangin/claims/${claim.id}/units`, { method: "POST", body: fd });
      setResult(res);
      setCap(null);
      setF((x) => ({ ...x, lengthCm: "", widthCm: "", depthCm: "" }));
      void load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  if (!claim) return <p className="container-page py-10 text-ink-muted">{r.loading}</p>;
  const { spec } = PULANGIN;
  const reason = result && (t.lang === "en" ? result.reasonEn : result.reason);

  return (
    <form onSubmit={submit} className="container-page max-w-2xl space-y-5 py-8">
      <Link href="/pulangin-air/tugas" className="inline-flex items-center gap-1 text-sm text-ink-muted hover:text-ink">
        <ArrowLeft className="h-4 w-4" /> {r.back}
      </Link>
      <header>
        <h1 className="text-2xl font-extrabold text-ink">{r.heading(claim.order.code)}</h1>
        <p className="text-sm text-ink-muted">
          {r.remaining(claim.owed, claim.slots)} {r.instruction(claim.order.code)}
        </p>
      </header>

      {result && (
        <div className={cx("card text-sm", result.status === "rejected" ? "border-rose-500/50" : "border-emerald-500/50")} role="status">
          <p className="font-semibold text-ink">{result.status === "rejected" ? r.rejectedTitle : r.sentTitle}</p>
          {reason && <p className="mt-1 text-rose-500">{reason}</p>}
          <ul className="mt-2 space-y-0.5 text-xs text-ink-muted">
            {result.checks.map((c) => (
              <li key={c.id}>
                {c.level === "pass" ? "✓" : c.level === "fail" ? "✗" : "•"} {checkText(c, t.lang)}
              </li>
            ))}
          </ul>
        </div>
      )}

      {claim.owed > 0 ? (
        <>
          <div className="card space-y-3">
            <p className="text-sm font-semibold text-ink">{r.area}</p>
            <AreaMap
              center={claim.order.center}
              radiusM={claim.order.radiusM}
              points={cap ? [{ id: "me", point: cap.point, label: r.thisUnit }] : []}
              height={220}
            />
          </div>

          <div className="card">
            <LiveCapture orderCode={claim.order.code} onCapture={setCap} />
          </div>

          <div className="card grid gap-4 sm:grid-cols-2">
            <Field label={r.type}>
              <select className="input mt-1 w-full" value={f.structureType} onChange={set("structureType")}>
                {spec.allowedTypes.map((v) => (
                  <option key={v} value={v}>
                    {r.types[v] ?? v}
                  </option>
                ))}
              </select>
            </Field>
            <Field label={r.shape}>
              <select className="input mt-1 w-full" value={f.shape} onChange={set("shape")}>
                {spec.allowedShapes.map((v) => (
                  <option key={v} value={v}>
                    {r.shapes[v] ?? v}
                  </option>
                ))}
              </select>
            </Field>
            {(
              [
                ["lengthCm", r.length, spec.minLengthCm],
                ["widthCm", r.width, spec.minWidthCm],
                ["depthCm", r.depth, spec.minDepthCm],
              ] as const
            ).map(([k, label, min]) => (
              <Field key={k} label={label} hint={r.min(min)}>
                <input type="number" inputMode="numeric" min={min} required className="input mt-1 w-full" value={f[k]} onChange={set(k)} />
              </Field>
            ))}
            <Field label={r.position}>
              <select className="input mt-1 w-full" value={f.position} onChange={set("position")}>
                {POSITIONS.map((v) => (
                  <option key={v} value={v}>
                    {r.positions[v] ?? v}
                  </option>
                ))}
              </select>
            </Field>
            <Field label={r.fill}>
              <select className="input mt-1 w-full" value={f.fillMaterial} onChange={set("fillMaterial")}>
                {FILLS.map((v) => (
                  <option key={v} value={v}>
                    {r.fills[v] ?? v}
                  </option>
                ))}
              </select>
            </Field>
            <Field label={r.owner}>
              <input className="input mt-1 w-full" required value={f.landownerName} onChange={set("landownerName")} />
            </Field>
            <Field label={r.ownerPhone} hint={r.ownerPhoneHint}>
              <input type="tel" className="input mt-1 w-full" value={f.landownerPhone} onChange={set("landownerPhone")} />
            </Field>
            <label className="flex gap-2 text-sm text-ink-muted sm:col-span-2">
              <input type="checkbox" checked={f.consent} onChange={set("consent")} required />
              {r.consent}
            </label>
          </div>

          {error && (
            <p className="text-sm text-rose-500" role="alert">
              {error}
            </p>
          )}
          <button className="btn-primary w-full" disabled={!cap || busy}>
            <Send className="h-4 w-4" /> {busy ? r.sending : r.send}
          </button>
        </>
      ) : (
        <p className="card text-sm text-ink-muted">{r.allDone}</p>
      )}
    </form>
  );
}
