"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Shovel, Wallet } from "lucide-react";
import { useT } from "@/components/pulangin/lang";
import { OrderCard, useOpenOrders } from "@/components/pulangin/open-orders";
import { Field, api, rupiah } from "@/components/pulangin/ui";
import { PULANGIN } from "@/lib/pulangin/config";

type MyClaim = {
  id: string;
  status: string;
  slots: number;
  owed: number;
  expiresAt: string;
  order: { id: string; code: string; regency: string | null; builderFeeIdr: number };
  units: { id: string; status: string; payoutStatus: string; reviewNote: string | null }[];
};
type Account = { bankCode: string; accountNumber: string; accountName: string; verified: boolean } | null;

const BANKS = [
  ["bca", "BCA"], ["bri", "BRI"], ["bni", "BNI"], ["mandiri", "Mandiri"], ["bsm", "BSI"],
  ["gopay", "GoPay"], ["ovo", "OVO"], ["dana", "DANA"], ["shopeepay", "ShopeePay"],
] as const;

export default function BuilderPage() {
  const t = useT();
  const b = t.build;
  const { orders, reload } = useOpenOrders();
  const [claims, setClaims] = useState<MyClaim[] | null>(null);
  const [account, setAccount] = useState<Account>(null);
  const [signedIn, setSignedIn] = useState(true);
  const [msg, setMsg] = useState<string | null>(null);

  const loadMine = () => {
    api<{ claims: MyClaim[] }>("/api/pulangin/claims").then((r) => setClaims(r.claims)).catch(() => setSignedIn(false));
    api<{ account: Account }>("/api/pulangin/payout-account").then((r) => setAccount(r.account)).catch(() => {});
  };
  useEffect(loadMine, []);

  async function claim(orderId: string, slots: number) {
    setMsg(null);
    try {
      await api(`/api/pulangin/orders/${orderId}/claims`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slots }),
      });
      setMsg(b.claimed(slots));
      loadMine();
      void reload();
    } catch (e) {
      setMsg((e as Error).message);
    }
  }

  const active = claims?.filter((c) => c.status === "active") ?? [];
  const paidOut = (claims ?? [])
    .flatMap((c) => c.units.filter((u) => u.payoutStatus === "paid").map(() => c.order.builderFeeIdr))
    .reduce((a, n) => a + n, 0);

  return (
    <div className="container-page space-y-8 py-10">
      <header>
        <h1 className="flex items-center gap-2 text-2xl font-extrabold text-ink">
          <Shovel className="h-6 w-6 text-emerald-500" /> {b.heading}
        </h1>
        <p className="mt-1 text-sm text-ink-muted">{b.sub}</p>
        {!signedIn && (
          <p className="mt-3 text-sm">
            <Link href="/sign-in" className="btn-primary">
              {b.signInToClaim}
            </Link>
          </p>
        )}
      </header>

      {msg && (
        <p className="card text-sm text-ink" role="status">
          {msg}
        </p>
      )}

      {signedIn && <PayoutAccount account={account} onSaved={setAccount} />}

      {active.length > 0 && (
        <section>
          <h2 className="text-lg font-bold text-ink">{b.active}</h2>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {active.map((c) => (
              <div key={c.id} className="card flex items-center justify-between gap-3">
                <div>
                  <p className="font-mono text-xs text-ink-subtle">{c.order.code}</p>
                  <p className="font-semibold text-ink">{b.owed(c.owed, c.slots)}</p>
                  <p className="text-xs text-ink-muted">{b.due(new Date(c.expiresAt).toLocaleDateString(t.locale, { dateStyle: "medium" }))}</p>
                  {c.units
                    .filter((u) => u.status === "rejected")
                    .slice(0, 1)
                    .map((u) => (
                      <p key={u.id} className="mt-1 text-xs text-rose-500">
                        {b.rejected(u.reviewNote ?? "")}
                      </p>
                    ))}
                </div>
                {c.owed > 0 && (
                  <Link href={`/pulangin-air/tugas/${c.id}`} className="btn-primary shrink-0">
                    {b.report}
                  </Link>
                )}
              </div>
            ))}
          </div>
          {paidOut > 0 && (
            <p className="mt-2 text-sm text-ink-muted">
              {b.paidOut} <strong className="text-emerald-500">{rupiah(paidOut)}</strong>
            </p>
          )}
        </section>
      )}

      <section>
        <h2 className="text-lg font-bold text-ink">{b.open}</h2>
        <p className="text-xs text-ink-muted">{b.openHint}</p>
        <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {orders === null && <p className="text-sm text-ink-muted">{t.loading}</p>}
          {orders?.length === 0 && <p className="text-sm text-ink-muted">{b.noOpen}</p>}
          {orders?.map((o) => {
            const free = Math.max(0, o.quantity - o.slotsClaimed - o.unitsApproved);
            return (
              <OrderCard
                key={o.id}
                o={o}
                action={
                  free > 0 && signedIn ? (
                    <ClaimButton
                      max={Math.min(free, PULANGIN.timing.maxActiveSlotsPerBuilder)}
                      onClaim={(n) => claim(o.id, n)}
                      disabled={!account?.verified}
                    />
                  ) : undefined
                }
              />
            );
          })}
        </div>
      </section>
    </div>
  );
}

function ClaimButton({ max, onClaim, disabled }: { max: number; onClaim: (n: number) => void; disabled: boolean }) {
  const t = useT();
  const [n, setN] = useState(Math.min(5, max));
  return (
    <span className="flex items-center gap-1">
      <input
        type="number"
        min={1}
        max={max}
        value={n}
        onChange={(e) => setN(Math.max(1, Math.min(max, Number(e.target.value) || 1)))}
        className="input w-16 py-1"
        aria-label={t.card.slotsLabel}
      />
      <button
        type="button"
        className="btn-primary px-3 py-1.5"
        disabled={disabled}
        title={disabled ? t.card.verifyAccountFirst : undefined}
        onClick={() => onClaim(n)}
      >
        {t.card.claim}
      </button>
    </span>
  );
}

function PayoutAccount({ account, onSaved }: { account: Account; onSaved: (a: Account) => void }) {
  const t = useT();
  const b = t.build;
  const [editing, setEditing] = useState(false);
  const [bankCode, setBank] = useState("bca");
  const [accountNumber, setNum] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (account?.verified && !editing) {
    return (
      <div className="card flex items-center justify-between text-sm">
        <span className="flex items-center gap-2 text-ink-muted">
          <Wallet className="h-4 w-4 text-emerald-500" /> {b.payTo(account.bankCode.toUpperCase(), account.accountNumber, account.accountName)}
        </span>
        <button type="button" className="btn-ghost" onClick={() => setEditing(true)}>
          {b.change}
        </button>
      </div>
    );
  }
  return (
    <form
      className="card grid gap-3 sm:grid-cols-[160px_1fr_auto] sm:items-end"
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setErr(null);
        try {
          const r = await api<{ account: Account }>("/api/pulangin/payout-account", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ bankCode, accountNumber }),
          });
          onSaved(r.account);
          setEditing(false);
        } catch (e2) {
          setErr((e2 as Error).message);
        } finally {
          setBusy(false);
        }
      }}
    >
      <p className="text-sm font-semibold text-ink sm:col-span-3">{b.acctTitle}</p>
      <Field label={b.bank}>
        <select className="input mt-1 w-full" value={bankCode} onChange={(e) => setBank(e.target.value)}>
          {BANKS.map(([v, l]) => (
            <option key={v} value={v}>
              {l}
            </option>
          ))}
        </select>
      </Field>
      <Field label={b.acctNo} hint={b.acctHint}>
        <input className="input mt-1 w-full" inputMode="numeric" value={accountNumber} onChange={(e) => setNum(e.target.value)} required />
      </Field>
      <button className="btn-primary" disabled={busy}>
        {busy ? b.checking : b.save}
      </button>
      {err && <p className="text-sm text-rose-500 sm:col-span-3">{err}</p>}
    </form>
  );
}
