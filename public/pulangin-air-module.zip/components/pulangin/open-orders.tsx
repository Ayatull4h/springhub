"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { MapPin } from "lucide-react";
import type { Order } from "@/lib/pulangin/types";
import { useT } from "./lang";
import { OrderBadge, Progress, api, rupiah } from "./ui";

export function useOpenOrders() {
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const reload = () =>
    api<{ orders: Order[] }>("/api/pulangin/orders")
      .then((r) => setOrders(r.orders))
      .catch((e: Error) => setError(e.message));
  useEffect(() => {
    void reload();
  }, []);
  return { orders, error, reload };
}

export function OrderCard({ o, action }: { o: Order; action?: React.ReactNode }) {
  const t = useT();
  const free = Math.max(0, o.quantity - o.slotsClaimed - o.unitsApproved);
  const radius = o.radiusM >= 1000 ? `${o.radiusM / 1000} km` : `${o.radiusM} m`;
  return (
    <article className="card flex flex-col gap-3">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-mono text-xs text-ink-subtle">{o.code}</p>
          <h3 className="font-semibold text-ink">
            {t.units(o.quantity)} · {o.regency ?? t.card.pickedBySpringhub}
          </h3>
        </div>
        <OrderBadge status={o.status} />
      </div>
      <p className="flex items-center gap-1 text-xs text-ink-muted">
        <MapPin className="h-3.5 w-3.5" /> {t.card.area(radius)}
        {o.province ? ` · ${o.province}` : ""}
      </p>
      {o.message && (
        <p className="line-clamp-2 text-sm text-ink-muted">
          “{o.message}” · {o.creditName}
        </p>
      )}
      <Progress done={o.unitsApproved} total={o.quantity} />
      <div className="mt-auto flex items-center justify-between border-t border-ink-line pt-3 text-sm">
        <span className="text-ink-muted">
          <strong className="text-emerald-500">{rupiah(o.builderFeeIdr)}</strong> {t.card.perUnit} · {t.card.slots(free)}
        </span>
        {action ?? (
          <Link href={`/pulangin-air/pesanan/${o.id}`} className="font-semibold text-emerald-500">
            {t.card.view}
          </Link>
        )}
      </div>
    </article>
  );
}
