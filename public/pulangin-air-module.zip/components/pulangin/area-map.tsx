"use client";

// Leaflet + OpenStreetMap, same stack as the live spring map.
// Mount with next/dynamic({ ssr: false }).

import { Circle, CircleMarker, MapContainer, TileLayer, Tooltip, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import type { LatLng } from "@/lib/pulangin/types";

type Props = {
  center: LatLng | null;
  radiusM?: number;
  points?: { id: string; point: LatLng; label?: string }[];
  onPick?: (p: LatLng) => void;
  height?: number;
};

function Picker({ onPick }: { onPick: (p: LatLng) => void }) {
  useMapEvents({ click: (e) => onPick({ lat: e.latlng.lat, lng: e.latlng.lng }) });
  return null;
}

export default function AreaMap({ center, radiusM, points = [], onPick, height = 320 }: Props) {
  const c = center ?? { lat: -7.6, lng: 110.4 };
  return (
    <MapContainer
      key={center ? "set" : "unset"}
      center={[c.lat, c.lng]}
      zoom={center ? 14 : 7}
      scrollWheelZoom={false}
      className="w-full overflow-hidden rounded-xl"
      style={{ height }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {onPick && <Picker onPick={onPick} />}
      {center && radiusM ? (
        <Circle
          center={[center.lat, center.lng]}
          radius={radiusM}
          pathOptions={{ color: "#0284c7", weight: 1.5, fillOpacity: 0.08, dashArray: "4 4" }}
        />
      ) : null}
      {points.map((p) => (
        <CircleMarker
          key={p.id}
          center={[p.point.lat, p.point.lng]}
          radius={6}
          pathOptions={{ color: "#fff", weight: 2, fillColor: "#10b981", fillOpacity: 1 }}
        >
          {p.label && <Tooltip>{p.label}</Tooltip>}
        </CircleMarker>
      ))}
    </MapContainer>
  );
}
