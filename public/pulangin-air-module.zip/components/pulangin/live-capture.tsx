"use client";

// In-app camera + GPS capture. The shutter stays disabled until the phone's
// GPS accuracy is within the limit, and the order code, time and coordinates
// are burned into the photo, so a picture can't be reused for another order.

import { useEffect, useRef, useState } from "react";
import { Camera, LocateFixed, RotateCcw } from "lucide-react";
import { PULANGIN } from "@/lib/pulangin/config";
import { useT } from "./lang";
import { cx } from "./ui";

export type Capture = {
  blob: Blob;
  previewUrl: string;
  point: { lat: number; lng: number };
  accuracyM: number;
  capturedAt: Date;
  liveCapture: boolean;
};

export function LiveCapture({ orderCode, onCapture }: { orderCode: string; onCapture: (c: Capture | null) => void }) {
  const video = useRef<HTMLVideoElement>(null);
  const [fix, setFix] = useState<GeolocationPosition | null>(null);
  const [geoError, setGeoError] = useState<string | null>(null);
  const [camError, setCamError] = useState<string | null>(null);
  const [shot, setShot] = useState<Capture | null>(null);
  const maxAcc = PULANGIN.geo.maxGpsAccuracyM;
  const t = useT();

  useEffect(() => {
    if (!("geolocation" in navigator)) return setGeoError(t.capture.noGps);
    const id = navigator.geolocation.watchPosition(setFix, (e) => setGeoError(e.message), {
      enableHighAccuracy: true,
      maximumAge: 0,
      timeout: 30_000,
    });
    return () => navigator.geolocation.clearWatch(id);
  }, []);

  useEffect(() => {
    if (shot) return;
    let stream: MediaStream | null = null;
    navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode: "environment", width: { ideal: 1600 } }, audio: false })
      .then((s) => {
        stream = s;
        if (video.current) video.current.srcObject = s;
      })
      .catch(() => setCamError(t.capture.camError));
    return () => stream?.getTracks().forEach((t) => t.stop());
  }, [shot]);

  const acc = fix?.coords.accuracy ?? Infinity;
  const ready = acc <= maxAcc;

  function stamp(canvas: HTMLCanvasElement, when: Date, f: GeolocationPosition) {
    const ctx = canvas.getContext("2d")!;
    const pad = Math.round(canvas.width * 0.02);
    const size = Math.max(14, Math.round(canvas.width * 0.028));
    const lines = [
      `${orderCode}  ·  ${t.title}`,
      `${when.toLocaleString(t.locale)}  ·  ±${Math.round(f.coords.accuracy)} m`,
      `${f.coords.latitude.toFixed(6)}, ${f.coords.longitude.toFixed(6)}`,
    ];
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillRect(0, canvas.height - lines.length * size * 1.4 - pad * 2, canvas.width, lines.length * size * 1.4 + pad * 2);
    ctx.fillStyle = "#fff";
    ctx.font = `600 ${size}px Inter, system-ui, sans-serif`;
    lines.forEach((l, i) => ctx.fillText(l, pad, canvas.height - pad - (lines.length - 1 - i) * size * 1.4));
  }

  async function finish(canvas: HTMLCanvasElement, live: boolean) {
    if (!fix) return;
    const when = new Date();
    stamp(canvas, when, fix);
    const blob = await new Promise<Blob>((r) => canvas.toBlob((b) => r(b!), "image/jpeg", 0.85));
    const c: Capture = {
      blob,
      previewUrl: URL.createObjectURL(blob),
      point: { lat: fix.coords.latitude, lng: fix.coords.longitude },
      accuracyM: fix.coords.accuracy,
      capturedAt: when,
      liveCapture: live,
    };
    setShot(c);
    onCapture(c);
  }

  function takeLive() {
    const v = video.current;
    if (!v || !ready) return;
    const canvas = document.createElement("canvas");
    canvas.width = v.videoWidth;
    canvas.height = v.videoHeight;
    canvas.getContext("2d")!.drawImage(v, 0, 0);
    void finish(canvas, true);
  }

  async function fromFile(file: File) {
    if (!ready) return;
    const img = await createImageBitmap(file);
    const scale = Math.min(1, 1600 / img.width);
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(img.width * scale);
    canvas.height = Math.round(img.height * scale);
    canvas.getContext("2d")!.drawImage(img, 0, 0, canvas.width, canvas.height);
    void finish(canvas, false);
  }

  return (
    <div className="space-y-3">
      <div
        className={cx(
          "flex items-center gap-2 rounded-lg px-3 py-2 text-sm",
          ready ? "bg-emerald-500/15 text-emerald-500" : "bg-amber-500/15 text-amber-500"
        )}
        aria-live="polite"
      >
        <LocateFixed className="h-4 w-4" />
        {geoError
          ? t.capture.gpsError(geoError)
          : fix
            ? t.capture.acc(Math.round(acc), ready)
            : t.capture.searching}
      </div>

      {shot ? (
        <div className="space-y-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={shot.previewUrl} alt={t.capture.photoAlt} className="w-full rounded-xl" />
          <button
            type="button"
            className="btn-secondary w-full"
            onClick={() => {
              setShot(null);
              onCapture(null);
            }}
          >
            <RotateCcw className="h-4 w-4" /> {t.capture.retake}
          </button>
        </div>
      ) : (
        <div className="space-y-2">
          {!camError && <video ref={video} autoPlay playsInline muted className="aspect-[4/3] w-full rounded-xl bg-black object-cover" />}
          {camError && <p className="text-sm text-amber-500">{camError}</p>}
          {!camError && (
            <button type="button" className="btn-primary w-full" disabled={!ready} onClick={takeLive}>
              <Camera className="h-4 w-4" /> {t.capture.shoot}
            </button>
          )}
          <label className={cx("block text-center text-xs text-ink-muted", !ready && "opacity-50")}>
            {t.capture.galleryPre} <span className="underline">{t.capture.galleryLink}</span> {t.capture.galleryPost}
            <input
              type="file"
              accept="image/*"
              className="sr-only"
              disabled={!ready}
              onChange={(e) => e.target.files?.[0] && fromFile(e.target.files[0])}
            />
          </label>
        </div>
      )}
    </div>
  );
}
