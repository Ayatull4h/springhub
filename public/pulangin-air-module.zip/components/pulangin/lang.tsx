"use client";

import { createContext, useContext } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { DICTS, LOCALE_COOKIE, type Dict, type Lang } from "@/lib/pulangin/i18n";

const LangCtx = createContext<Lang>("id");

export function LangProvider({ lang, children }: { lang: Lang; children: React.ReactNode }) {
  return <LangCtx.Provider value={lang}>{children}</LangCtx.Provider>;
}

/** Current dictionary. Usage: const t = useT(); t.order.heading */
export function useT(): Dict {
  return DICTS[useContext(LangCtx)];
}

/** Current language for client code outside React (e.g. picking API error text). */
export function currentLang(): Lang {
  if (typeof document === "undefined") return "id";
  const m = document.cookie.match(new RegExp(`(?:^|; )${LOCALE_COOKIE}=([^;]+)`));
  return m && decodeURIComponent(m[1]).toLowerCase().startsWith("en") ? "en" : "id";
}

/** ID/EN toggle that writes the same cookie as the live site header. */
export function LangToggle() {
  const lang = useContext(LangCtx);
  const router = useRouter();
  const set = (l: Lang) => {
    document.cookie = `${LOCALE_COOKIE}=${l}; path=/; max-age=31536000; samesite=lax`;
    router.refresh();
  };
  return (
    <div role="group" aria-label={DICTS[lang].langSwitch} className="ml-auto flex shrink-0 overflow-hidden rounded-md border border-ink-line text-xs">
      {(["id", "en"] as const).map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => set(l)}
          aria-pressed={lang === l}
          className={lang === l ? "bg-sky-500/15 px-2.5 py-1.5 font-semibold text-sky-500" : "px-2.5 py-1.5 text-ink-muted hover:text-ink"}
        >
          {l.toUpperCase()}
        </button>
      ))}
    </div>
  );
}

export function SubNav() {
  const t = useT();
  const tabs = [
    { href: "/pulangin-air", label: t.nav.home },
    { href: "/pulangin-air/pesan", label: t.nav.order },
    { href: "/pulangin-air/tugas", label: t.nav.build },
    { href: "/pulangin-air/pesanan", label: t.nav.mine },
  ];
  return (
    <nav aria-label={t.title} className="border-b border-ink-line">
      <div className="container-page flex items-center gap-1 overflow-x-auto py-2 text-sm">
        {tabs.map((tab) => (
          <Link key={tab.href} href={tab.href} className="whitespace-nowrap rounded-md px-3 py-1.5 font-medium text-ink-muted hover:text-ink">
            {tab.label}
          </Link>
        ))}
        <LangToggle />
      </div>
    </nav>
  );
}
