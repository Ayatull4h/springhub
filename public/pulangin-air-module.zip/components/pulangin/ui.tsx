"use client";

// Small UI pieces. Uses the live SpringHub utility classes (card, chip,
// btn-primary, text-ink, text-ink-muted, border-ink-line) so the microsite
// follows the site's light/dark theme automatically.

import type { OrderStatus, UnitStatus } from "@/lib/pulangin/types";
import { currentLang, useT } from "./lang";

export { rupiah } from "@/lib/pulangin/i18n";

export function cx(...c: (string | false | null | undefined)[]) {
  return c.filter(Boolean).join(" ");
}

const ORDER_CLS: Record<OrderStatus, string> = {
  awaiting_payment: "bg-slate-500/15 text-slate-400",
  area_review: "bg-amber-500/15 text-amber-500",
  open: "bg-sky-500/15 text-sky-500",
  in_progress: "bg-indigo-500/15 text-indigo-400",
  fulfilled: "bg-emerald-500/15 text-emerald-500",
  expired: "bg-slate-500/15 text-slate-400",
  cancelled: "bg-rose-500/15 text-rose-500",
};

const UNIT_CLS: Record<UnitStatus, string> = {
  pending_review: "bg-sky-500/15 text-sky-500",
  flagged: "bg-amber-500/15 text-amber-500",
  field_audit: "bg-indigo-500/15 text-indigo-400",
  approved: "bg-emerald-500/15 text-emerald-500",
  rejected: "bg-rose-500/15 text-rose-500",
};

export function OrderBadge({ status }: { status: OrderStatus }) {
  const t = useT();
  return <span className={cx("chip", ORDER_CLS[status])}>{t.status[status]}</span>;
}

export function UnitBadge({ status }: { status: UnitStatus }) {
  const t = useT();
  return <span className={cx("chip", UNIT_CLS[status])}>{t.unitStatus[status]}</span>;
}

export function Progress({ done, total }: { done: number; total: number }) {
  const t = useT();
  const pct = total ? Math.min(100, Math.round((done / total) * 100)) : 0;
  return (
    <div>
      <div className="flex justify-between text-xs text-ink-muted">
        <span>{t.progress.verified}</span>
        <span className="tabular-nums">{t.progress.of(done, total)}</span>
      </div>
      <div className="mt-1 h-2 overflow-hidden rounded-full bg-slate-500/20" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
        <div className="h-full rounded-full bg-emerald-500 transition-all" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-sm font-medium text-ink">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-ink-subtle">{hint}</span>}
    </label>
  );
}

/** Fetch helper that surfaces API errors in the viewer's language. */
export async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, { credentials: "include", ...init });
  const data = (await res.json().catch(() => ({}))) as { error?: string; errorEn?: string };
  if (!res.ok) {
    const en = currentLang() === "en";
    throw new Error((en ? data.errorEn : data.error) ?? data.error ?? `${en ? "Failed" : "Gagal"} (${res.status})`);
  }
  return data as T;
}

/** Check detail in the viewer's language. */
export function checkText(c: { detail: string; detailEn?: string }, lang: "id" | "en") {
  return lang === "en" ? c.detailEn ?? c.detail : c.detail;
}

/** TODO(repo owner): map a storagePath to a URL the same way /api/reports photos are served. */
export const photoUrl = (path: string) => `/api/media?path=${encodeURIComponent(path)}`;
