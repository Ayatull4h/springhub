// Perceptual difference hash (dHash). Catches the same photo re-uploaded,
// re-compressed, resized or lightly cropped for a second "rorak".
// Server-only: uses sharp.

import sharp from "sharp";

/** 64-bit dHash as 16 hex chars. */
export async function dHash(image: Buffer): Promise<string> {
  const { data } = await sharp(image)
    .rotate() // respect EXIF orientation
    .grayscale()
    .resize(9, 8, { fit: "fill" })
    .raw()
    .toBuffer({ resolveWithObject: true });

  let bits = "";
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
      const left = data[y * 9 + x];
      const right = data[y * 9 + x + 1];
      bits += left > right ? "1" : "0";
    }
  }
  let hex = "";
  for (let i = 0; i < 64; i += 4) hex += parseInt(bits.slice(i, i + 4), 2).toString(16);
  return hex;
}

export function hamming(a: string, b: string): number {
  if (a.length !== b.length) return 64;
  let d = 0;
  for (let i = 0; i < a.length; i++) {
    let x = parseInt(a[i], 16) ^ parseInt(b[i], 16);
    while (x) {
      d += x & 1;
      x >>= 1;
    }
  }
  return d;
}
