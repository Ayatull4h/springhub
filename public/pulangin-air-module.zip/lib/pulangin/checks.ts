// Automatic verification of one delivered rorak (infiltration pit). Pure
// function: the caller loads the context from the DB, this decides.
// Every result carries Indonesian `detail` and English `detailEn`.

import { PULANGIN } from "./config";
import { distanceM } from "./geo";
import { hamming } from "./phash";
import type { CheckLevel, CheckResult, Claim, LatLng, Order, UnitStatus } from "./types";

export type UnitSubmission = {
  point: LatLng;
  accuracyM: number;
  capturedAt: Date;
  receivedAt: Date;
  liveCapture: boolean;
  queuedOffline: boolean;
  photoHash: string;
  structureType: string;
  shape: string;
  lengthCm: number;
  widthCm: number;
  depthCm: number;
};

export type CheckContext = {
  order: Pick<Order, "center" | "radiusM">;
  claim: Pick<Claim, "createdAt" | "expiresAt">;
  /** Non-rejected units (any order) within ~nearDuplicateM, from a bbox query. */
  nearbyUnits: { id: string; point: LatLng; photoHash: string }[];
  /** Count of non-rejected units (any order) already in this unit's cell. */
  unitsInCell: number;
  /** Recent photo hashes to compare against (same builder + same area). */
  knownPhotoHashes: { unitId: string; hash: string }[];
  /** Injected for deterministic tests. */
  random?: () => number;
};

export type CheckOutcome = {
  status: Extract<UnitStatus, "pending_review" | "flagged" | "field_audit" | "rejected">;
  checks: CheckResult[];
  /** Reason when rejected, Indonesian and English. */
  reason: string | null;
  reasonEn: string | null;
};

const c = (id: CheckResult["id"], level: CheckLevel, detail: string, detailEn: string): CheckResult => ({
  id,
  level,
  detail,
  detailEn,
});

export function runAutoChecks(s: UnitSubmission, ctx: CheckContext): CheckOutcome {
  const g = PULANGIN.geo;
  const spec = PULANGIN.spec;
  const t = PULANGIN.timing;
  const checks: CheckResult[] = [];
  const add = (r: CheckResult) => checks.push(r);
  const acc = Math.round(s.accuracyM);

  // 1. GPS accuracy, same limit as the live trench form.
  add(
    s.accuracyM <= g.maxGpsAccuracyM
      ? c("gps_accuracy", "pass", `Akurasi GPS ±${acc} m`, `GPS accuracy ±${acc} m`)
      : c("gps_accuracy", "fail", `Akurasi GPS ±${acc} m, batas ${g.maxGpsAccuracyM} m`, `GPS accuracy ±${acc} m, limit ${g.maxGpsAccuracyM} m`)
  );

  // 2. Inside the order area (tolerate GPS error at the edge).
  const fromCenter = Math.round(distanceM(s.point, ctx.order.center));
  const allowed = ctx.order.radiusM + Math.min(s.accuracyM, g.maxGpsAccuracyM);
  add(
    fromCenter <= allowed
      ? c("inside_area", "pass", `${fromCenter} m dari pusat area`, `${fromCenter} m from the area centre`)
      : c(
          "inside_area",
          "fail",
          `${fromCenter} m dari pusat, area pesanan ${ctx.order.radiusM} m`,
          `${fromCenter} m from the centre, order area is ${ctx.order.radiusM} m`
        )
  );

  // 3. Captured during the claim window.
  const created = new Date(ctx.claim.createdAt).getTime();
  const expires = new Date(ctx.claim.expiresAt).getTime();
  const cap = s.capturedAt.getTime();
  add(
    cap >= created && cap <= expires
      ? c("claim_window", "pass", "Difoto dalam masa klaim", "Taken during the claim period")
      : c("claim_window", "fail", "Foto diambil di luar masa klaim", "Photo taken outside the claim period")
  );

  // 4. Freshness: photo should reach us soon after capture.
  const ageMin = (s.receivedAt.getTime() - cap) / 60_000;
  const mins = Math.max(0, Math.round(ageMin));
  if (ageMin < -5) {
    add(c("capture_fresh", "fail", "Waktu foto di masa depan (jam HP salah?)", "Photo time is in the future (wrong phone clock?)"));
  } else if (ageMin <= t.captureFreshMin) {
    add(c("capture_fresh", "pass", `Terkirim ${mins} menit setelah difoto`, `Sent ${mins} min after capture`));
  } else if (s.queuedOffline && ageMin <= t.offlineGraceHours * 60) {
    const h = Math.round(ageMin / 60);
    add(c("capture_fresh", "flag", `Antrean offline, terkirim ${h} jam kemudian`, `Offline queue, sent ${h} h later`));
  } else {
    add(c("capture_fresh", "fail", `Terkirim ${mins} menit setelah difoto`, `Sent ${mins} min after capture`));
  }

  // 5. Structure type and shape.
  const typeOk = (spec.allowedTypes as readonly string[]).includes(s.structureType);
  const shapeOk = (spec.allowedShapes as readonly string[]).includes(s.shape);
  add(
    typeOk && shapeOk
      ? c("structure_type", "pass", `${s.structureType}, ${s.shape}`, `${s.structureType}, ${s.shape}`)
      : c(
          "structure_type",
          "fail",
          `Bukan rorak/parit resapan berbentuk kotak (${s.structureType}, ${s.shape})`,
          `Not a box-shaped infiltration pit or trench (${s.structureType}, ${s.shape})`
        )
  );

  // 6. Minimum dimensions.
  const dimOk = s.lengthCm >= spec.minLengthCm && s.widthCm >= spec.minWidthCm && s.depthCm >= spec.minDepthCm;
  const dims = `${s.lengthCm} × ${s.widthCm} × ${s.depthCm} cm`;
  const mins3 = `${spec.minLengthCm} × ${spec.minWidthCm} × ${spec.minDepthCm}`;
  add(c("dimensions", dimOk ? "pass" : "fail", `${dims} (min ${mins3})`, `${dims} (min ${mins3})`));

  // 7. Photo re-use. Strongest anti-replication signal we have.
  const dup = ctx.knownPhotoHashes.find((k) => hamming(k.hash, s.photoHash) <= PULANGIN.photo.duplicateHammingMax);
  add(
    dup
      ? c("photo_duplicate", "fail", `Foto mirip dengan unit ${dup.unitId.slice(0, 8)}`, `Photo matches pit ${dup.unitId.slice(0, 8)}`)
      : c("photo_duplicate", "pass", "Foto unik", "Unique photo")
  );

  // 8. Near-duplicate point. GPS noise means this alone is only a flag.
  const near = ctx.nearbyUnits.filter((u) => distanceM(u.point, s.point) <= g.nearDuplicateM).length;
  add(
    near
      ? c("near_duplicate", "flag", `${near} rorak lain dalam ${g.nearDuplicateM} m`, `${near} other pit(s) within ${g.nearDuplicateM} m`)
      : c("near_duplicate", "pass", "Tidak ada rorak lain berdekatan", "No other pit close by")
  );

  // 9. Cell capacity: the enforceable "no replication in the same area" rule.
  add(
    ctx.unitsInCell < g.cellCapacity
      ? c(
          "cell_capacity",
          "pass",
          `${ctx.unitsInCell + 1}/${g.cellCapacity} di petak ±22 m`,
          `${ctx.unitsInCell + 1}/${g.cellCapacity} in the ±22 m cell`
        )
      : c(
          "cell_capacity",
          "fail",
          `Petak ±22 m sudah berisi ${ctx.unitsInCell} rorak (maks ${g.cellCapacity})`,
          `The ±22 m cell already holds ${ctx.unitsInCell} pits (max ${g.cellCapacity})`
        )
  );

  // 10. Capture source.
  add(
    s.liveCapture
      ? c("live_capture", "pass", "Difoto langsung dari kamera aplikasi", "Taken live in the app camera")
      : c("live_capture", "flag", "Diunggah dari galeri, bukan kamera langsung", "Uploaded from the gallery, not the live camera")
  );

  // 11. Human-only check: order code on the stake/paper must be readable.
  add(c("code_visible", "manual", "Pastikan kode pesanan terbaca di foto", "Make sure the order code is readable in the photo"));

  const failed = checks.filter((r) => r.level === "fail");
  if (failed.length) {
    return {
      status: "rejected",
      checks,
      reason: failed.map((r) => r.detail).join("; "),
      reasonEn: failed.map((r) => r.detailEn).join("; "),
    };
  }

  if (checks.some((r) => r.level === "flag")) return { status: "flagged", checks, reason: null, reasonEn: null };

  if ((ctx.random ?? Math.random)() < PULANGIN.review.randomFieldAuditPct) {
    checks.push(c("random_audit", "flag", "Terpilih acak untuk cek lapangan", "Randomly picked for a field check"));
    return { status: "field_audit", checks, reason: null, reasonEn: null };
  }
  return { status: "pending_review", checks, reason: null, reasonEn: null };
}
