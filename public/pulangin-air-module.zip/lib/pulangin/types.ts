// Shared types. JSON shapes follow the live SpringHub API style:
// camelCase keys, UUID ids, ISO timestamps.

export type LatLng = { lat: number; lng: number };

export type Role = "public" | "volunteer" | "field_lead" | "admin";

export type SessionUser = {
  id: string;
  username: string;
  role: Role;
};

/** Order lifecycle (buyer side, like an e-commerce order). */
export type OrderStatus =
  | "awaiting_payment" // Midtrans Snap created, not settled
  | "area_review" // paid, custom pin waiting for field lead to confirm the site
  | "open" // paid and visible on the job board
  | "in_progress" // every slot is claimed or delivered, not all approved yet
  | "fulfilled" // all units approved
  | "expired" // passed expiry with slots left; fallback applied
  | "cancelled"; // payment failed / expired at Midtrans

/** What happens to money for undelivered slots when an order expires. */
export type OrderFallback = "reallocate" | "refund";

export type OrderTarget =
  | { kind: "spring"; springId: string }
  | { kind: "springhub_pick" } // SpringHub assigns a priority catchment
  | { kind: "custom_pin" }; // buyer-chosen point, needs area review

export type Order = {
  id: string;
  code: string; // short code builders write on the stake, e.g. PA-7K3Q
  buyerId: string;
  creditName: string; // public credit, may be "Anonim"
  message: string | null;
  target: OrderTarget;
  center: LatLng;
  radiusM: number;
  regency: string | null;
  province: string | null;
  quantity: number;
  unitPriceIdr: number;
  builderFeeIdr: number;
  grossIdr: number;
  fallback: OrderFallback;
  status: OrderStatus;
  paidAt: string | null;
  expiresAt: string | null;
  createdAt: string;
  /** Derived counters. */
  slotsClaimed: number;
  unitsApproved: number;
};

export type ClaimStatus = "active" | "completed" | "expired" | "cancelled";

export type Claim = {
  id: string;
  orderId: string;
  builderId: string;
  slots: number;
  status: ClaimStatus;
  createdAt: string;
  expiresAt: string;
};

export type UnitStatus =
  | "pending_review" // passed auto checks, waiting for a human
  | "flagged" // auto checks raised a warning, careful review
  | "field_audit" // sent for an on-site check
  | "approved"
  | "rejected";

export type PayoutStatus = "none" | "queued" | "processing" | "paid" | "failed";

export type CheckLevel = "pass" | "flag" | "fail" | "manual";

export type CheckResult = {
  id:
    | "gps_accuracy"
    | "inside_area"
    | "capture_fresh"
    | "claim_window"
    | "structure_type"
    | "dimensions"
    | "near_duplicate"
    | "cell_capacity"
    | "photo_duplicate"
    | "live_capture"
    | "code_visible"
    | "random_audit";
  level: CheckLevel;
  detail: string;
  /** English version of `detail`. */
  detailEn: string;
};

/** One delivered rorak. */
export type RorakUnit = {
  id: string;
  orderId: string;
  claimId: string;
  builderId: string;
  /** Id of the mirrored row in the live /api/reports table, once synced. */
  reportId: string | null;
  point: LatLng;
  accuracyM: number;
  cellId: string;
  capturedAt: string;
  receivedAt: string;
  liveCapture: boolean; // in-app camera (true) vs file picker fallback (false)
  queuedOffline: boolean;
  photoPath: string;
  photoHash: string; // 64-bit dHash, hex
  structureType: string;
  shape: string;
  lengthCm: number;
  widthCm: number;
  depthCm: number;
  position: string | null;
  fillMaterial: string | null;
  landownerName: string;
  landownerPhone: string | null;
  checks: CheckResult[];
  status: UnitStatus;
  reviewerId: string | null;
  reviewNote: string | null;
  reviewedAt: string | null;
  payoutStatus: PayoutStatus;
  payoutRef: string | null;
};

export type BuilderPayoutAccount = {
  builderId: string;
  /** Iris bank code, e.g. "bca", "bni", "gopay". */
  bankCode: string;
  accountNumber: string;
  accountName: string;
  email: string | null;
  verifiedAt: string | null;
};
