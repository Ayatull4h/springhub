// State rules. Pure functions so the API routes stay thin and testable.

import { PULANGIN } from "./config";
import type { Claim, Order, OrderStatus, RorakUnit } from "./types";

export const ORDER_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  awaiting_payment: ["area_review", "open", "cancelled"],
  area_review: ["open", "expired"],
  open: ["in_progress", "fulfilled", "expired"],
  in_progress: ["open", "fulfilled", "expired"],
  fulfilled: [],
  expired: [],
  cancelled: [],
};

export function canTransition(from: OrderStatus, to: OrderStatus) {
  return from === to || ORDER_TRANSITIONS[from].includes(to);
}

/**
 * Slots still claimable on an order.
 * `committedOutsideActive` = non-rejected units whose claim is completed/expired
 * (approved units of active claims are already inside that claim's slots).
 */
export function freeSlots(
  order: Pick<Order, "quantity">,
  activeClaims: Pick<Claim, "slots" | "status">[],
  committedOutsideActive: number
) {
  const held = activeClaims.filter((c) => c.status === "active").reduce((n, c) => n + c.slots, 0);
  return Math.max(0, order.quantity - held - committedOutsideActive);
}

/**
 * Slots a claim still owes: claimed slots minus units that are approved or
 * still under review. Rejected units give the slot back to the same claim.
 */
export function owedOnClaim(claim: Pick<Claim, "slots">, units: Pick<RorakUnit, "status">[]) {
  const counted = units.filter((u) => u.status !== "rejected").length;
  return Math.max(0, claim.slots - counted);
}

export type OrderProgress = {
  /** Slots held by claims with status "active" (their units count inside). */
  activeClaimSlots: number;
  /** Non-rejected units (approved or in review) whose claim is no longer active. */
  committedOutsideActive: number;
  /** All approved units on the order. */
  approvedTotal: number;
  /** Units waiting for review (pending, flagged, field audit). */
  inReview: number;
};

/** Recompute order status after any claim/unit change. */
export function deriveOrderStatus(
  order: Pick<Order, "status" | "quantity"> & { expiresAt: Date | string | null },
  p: OrderProgress,
  now: Date = new Date()
): OrderStatus {
  const s = order.status;
  if (s === "awaiting_payment" || s === "area_review" || s === "cancelled" || s === "fulfilled" || s === "expired") {
    return s;
  }
  if (p.approvedTotal >= order.quantity) return "fulfilled";
  if (order.expiresAt && new Date(order.expiresAt) < now && p.activeClaimSlots === 0 && p.inReview === 0) {
    return "expired";
  }
  return p.committedOutsideActive + p.activeClaimSlots >= order.quantity ? "in_progress" : "open";
}

export type ClaimRequest = { slots: number };

export function validateClaim(
  req: ClaimRequest,
  free: number,
  builderActiveSlots: number
): { ok: true } | { ok: false; error: string } {
  if (!Number.isInteger(req.slots) || req.slots < 1) return { ok: false, error: "Jumlah slot tidak valid" };
  if (req.slots > free) return { ok: false, error: `Hanya tersisa ${free} slot` };
  const max = PULANGIN.timing.maxActiveSlotsPerBuilder;
  if (builderActiveSlots + req.slots > max) {
    return { ok: false, error: `Maksimal ${max} slot aktif per pembuat. Selesaikan dulu yang sedang berjalan.` };
  }
  return { ok: true };
}

export function claimExpiry(now: Date = new Date()) {
  return new Date(now.getTime() + PULANGIN.timing.claimHoldDays * 86_400_000);
}

export function orderExpiry(paidAt: Date) {
  return new Date(paidAt.getTime() + PULANGIN.timing.orderExpiryDays * 86_400_000);
}

/** Short human code, no ambiguous characters (0/O, 1/I/L). */
export function makeOrderCode(rand: () => number = Math.random) {
  const abc = "23456789ABCDEFGHJKMNPQRSTUVWXYZ";
  let s = "";
  for (let i = 0; i < 4; i++) s += abc[Math.floor(rand() * abc.length)];
  return `PA-${s}`;
}
