import { PULANGIN } from "./config";
import type { LatLng } from "./types";

const R_EARTH_M = 6_371_000;

export function distanceM(a: LatLng, b: LatLng): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R_EARTH_M * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Anti-replication cell id. Stable string, safe to index in the DB. */
export function cellIdOf(p: LatLng, deg: number = PULANGIN.geo.cellDeg): string {
  return `${Math.floor(p.lat / deg)}:${Math.floor(p.lng / deg)}`;
}

/**
 * Bounding box that contains every point within `radiusM` of `p`.
 * Use it to pre-filter candidates in SQL, then confirm with distanceM().
 */
export function bboxAround(p: LatLng, radiusM: number) {
  const dLat = (radiusM / R_EARTH_M) * (180 / Math.PI);
  const dLng = dLat / Math.max(0.01, Math.cos((p.lat * Math.PI) / 180));
  return {
    minLat: p.lat - dLat,
    maxLat: p.lat + dLat,
    minLng: p.lng - dLng,
    maxLng: p.lng + dLng,
  };
}

/** Coarsen a point for display to the buyer. */
export function coarsen(p: LatLng, deg: number = PULANGIN.geo.buyerPrecisionDeg): LatLng {
  return {
    lat: Math.round(p.lat / deg) * deg,
    lng: Math.round(p.lng / deg) * deg,
  };
}

/** Same 5 km grid the live site uses for public spring locations. */
export function snapPublic(p: LatLng): LatLng {
  return coarsen(p, 0.045);
}

export function isValidLatLng(p: Partial<LatLng> | null | undefined): p is LatLng {
  return (
    !!p &&
    typeof p.lat === "number" &&
    typeof p.lng === "number" &&
    Number.isFinite(p.lat) &&
    Number.isFinite(p.lng) &&
    Math.abs(p.lat) <= 90 &&
    Math.abs(p.lng) <= 180
  );
}

/** Rough Indonesia bounding box, rejects obviously wrong coordinates. */
export function isInIndonesia(p: LatLng): boolean {
  return p.lat >= -11.5 && p.lat <= 6.5 && p.lng >= 94.5 && p.lng <= 141.5;
}
