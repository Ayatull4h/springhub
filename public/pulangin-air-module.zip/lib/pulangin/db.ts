// Prisma client singleton.
// TODO(repo owner): if the live repo already exports a client (often
// `@/lib/prisma` or `@/lib/db`), re-export that instead to share one pool.
import { PrismaClient, type PaOrder, type PaUnit } from "@prisma/client";
import { coarsen, snapPublic } from "./geo";
import type { CheckResult, Order, OrderTarget, RorakUnit } from "./types";

const g = globalThis as unknown as { __springhubPrisma?: PrismaClient };
export const db: PrismaClient = g.__springhubPrisma ?? new PrismaClient();
if (process.env.NODE_ENV !== "production") g.__springhubPrisma = db;

export type Viewer = "public" | "builder_claimed" | "owner" | "reviewer";

function target(o: PaOrder): OrderTarget {
  if (o.targetKind === "spring" && o.springId) return { kind: "spring", springId: o.springId };
  if (o.targetKind === "custom_pin") return { kind: "custom_pin" };
  return { kind: "springhub_pick" };
}

/** Location precision depends on who is looking. */
export function serializeOrder(
  o: PaOrder,
  counts: { slotsClaimed: number; unitsApproved: number },
  viewer: Viewer
): Order {
  const precise = { lat: o.centerLat, lng: o.centerLng };
  const center =
    viewer === "reviewer" || viewer === "builder_claimed"
      ? precise
      : viewer === "owner"
        ? coarsen(precise)
        : snapPublic(precise);
  return {
    id: o.id,
    code: o.code,
    buyerId: viewer === "public" ? "" : o.buyerId,
    creditName: o.creditName,
    message: o.message,
    target: target(o),
    center,
    radiusM: o.radiusM,
    regency: o.regency,
    province: o.province,
    quantity: o.quantity,
    unitPriceIdr: o.unitPriceIdr,
    builderFeeIdr: o.builderFeeIdr,
    grossIdr: viewer === "public" ? 0 : o.grossIdr,
    fallback: o.fallback,
    status: o.status,
    paidAt: o.paidAt?.toISOString() ?? null,
    expiresAt: o.expiresAt?.toISOString() ?? null,
    createdAt: o.createdAt.toISOString(),
    ...counts,
  };
}

export function serializeUnit(u: PaUnit, viewer: Viewer): RorakUnit {
  const precise = { lat: u.lat, lng: u.lng };
  const showPrecise = viewer === "reviewer" || viewer === "builder_claimed";
  return {
    id: u.id,
    orderId: u.orderId,
    claimId: u.claimId,
    builderId: u.builderId,
    reportId: u.reportId,
    point: showPrecise ? precise : viewer === "owner" ? coarsen(precise) : snapPublic(precise),
    accuracyM: u.accuracyM,
    cellId: showPrecise ? u.cellId : "",
    capturedAt: u.capturedAt.toISOString(),
    receivedAt: u.receivedAt.toISOString(),
    liveCapture: u.liveCapture,
    queuedOffline: u.queuedOffline,
    photoPath: u.photoPath,
    photoHash: showPrecise ? u.photoHash : "",
    structureType: u.structureType,
    shape: u.shape,
    lengthCm: u.lengthCm,
    widthCm: u.widthCm,
    depthCm: u.depthCm,
    position: u.position,
    fillMaterial: u.fillMaterial,
    landownerName: viewer === "public" ? "" : u.landownerName,
    landownerPhone: viewer === "reviewer" ? u.landownerPhone : null,
    checks: viewer === "public" ? [] : (u.checks as unknown as CheckResult[]),
    status: u.status,
    reviewerId: viewer === "reviewer" ? u.reviewerId : null,
    reviewNote: u.reviewNote,
    reviewedAt: u.reviewedAt?.toISOString() ?? null,
    payoutStatus: viewer === "reviewer" || viewer === "builder_claimed" ? u.payoutStatus : "none",
    payoutRef: viewer === "reviewer" ? u.payoutRef : null,
  };
}

/** Counters used by order cards. */
export async function orderCounts(orderId: string) {
  const [claimAgg, approved] = await Promise.all([
    db.paClaim.aggregate({ where: { orderId, status: "active" }, _sum: { slots: true } }),
    db.paUnit.count({ where: { orderId, status: "approved" } }),
  ]);
  return { slotsClaimed: claimAgg._sum.slots ?? 0, unitsApproved: approved };
}

type Tx = Pick<PrismaClient, "paClaim" | "paUnit" | "paOrder">;

/** Everything deriveOrderStatus() and freeSlots() need, in one place. */
export async function orderProgress(tx: Tx, orderId: string) {
  const [activeClaims, committedOutsideActive, approvedTotal, inReview] = await Promise.all([
    tx.paClaim.findMany({ where: { orderId, status: "active" }, select: { slots: true, status: true } }),
    tx.paUnit.count({ where: { orderId, status: { not: "rejected" }, claim: { status: { not: "active" } } } }),
    tx.paUnit.count({ where: { orderId, status: "approved" } }),
    tx.paUnit.count({ where: { orderId, status: { in: ["pending_review", "flagged", "field_audit"] } } }),
  ]);
  return {
    activeClaims,
    progress: {
      activeClaimSlots: activeClaims.reduce((n, c) => n + c.slots, 0),
      committedOutsideActive,
      approvedTotal,
      inReview,
    },
  };
}
