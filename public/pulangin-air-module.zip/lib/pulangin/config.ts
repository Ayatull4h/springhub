// Pulangkan Air Hujan ke Rumahnya (EN: Return Water Home): business rules in one place.
// Rorak = infiltration pit in English copy.
// Every number here is a default to be confirmed by the Jaga Semesta team.
// Changing a value here changes behaviour everywhere (API, UI, checks).

export const PULANGIN = {
  /** Route prefix of the microsite: https://springhub.id/pulangin-air */
  basePath: "/pulangin-air",

  /**
   * Delivery reports reuse the live SpringHub form so every rorak sold here
   * also lands in /api/reports, the impact dashboard and the points engine.
   */
  reportFormSlug: "trench-development",

  pricing: {
    /** Price the buyer pays per rorak (IDR). */
    unitPriceIdr: 10_000,
    /** Share kept by Jaga Semesta for admin verification and the springhub.id platform. */
    platformSharePct: 0.2,
    /** Show the 80/20 split to buyers at checkout. */
    showFeeBreakdown: true,
    minQty: 1,
    maxQty: 500,
  },

  /** Minimum build spec. Units below spec fail automatically. */
  spec: {
    allowedTypes: ["Rorak", "Parit Resapan"] as const,
    allowedShapes: ["Kotak", "Persegi"] as const,
    minLengthCm: 100,
    minWidthCm: 30,
    minDepthCm: 30,
  },

  geo: {
    /** Matches the live trench form rule "GPS Accuracy (max 15m)". */
    maxGpsAccuracyM: 15,
    /**
     * Anti-replication grid. ~0.0002 deg is about 22 m at Indonesian latitudes.
     * Each cell may hold at most `cellCapacity` rorak across ALL orders.
     * Phone GPS error (up to 15 m) makes strict per-point uniqueness
     * impossible, so a capped cell is the enforceable rule.
     */
    cellDeg: 0.0002,
    cellCapacity: 3,
    /** Two units closer than this are treated as a possible re-submission. */
    nearDuplicateM: 3,
    defaultOrderRadiusM: 1_000,
    maxOrderRadiusM: 5_000,
    /** Precision of rorak points shown to the buyer (public stays on the 5 km grid). */
    buyerPrecisionDeg: 0.001, // about 110 m
  },

  photo: {
    /** dHash Hamming distance at or below this = same photo (re-used / re-cropped). */
    duplicateHammingMax: 6,
    maxBytes: 8 * 1024 * 1024,
  },

  timing: {
    /** Builder must deliver within this many days after claiming slots. */
    claimHoldDays: 14,
    /** Max slots one builder can hold at once (stops slot hoarding). */
    maxActiveSlotsPerBuilder: 20,
    /** Unfulfilled paid orders expire after this many days. */
    orderExpiryDays: 90,
    /** Photo must reach the server within this many minutes of capture... */
    captureFreshMin: 30,
    /** ...unless it was queued offline, then it is flagged, not failed. */
    offlineGraceHours: 72,
    /** Target review SLA shown to builders. */
    reviewSlaDays: 3,
  },

  review: {
    // Every unit needs a human approval before money moves (by design: photo
    // plus geotag alone is spoofable). Clean units are a one-click approve.
    /** Share of clean units randomly sent to a field audit. */
    randomFieldAuditPct: 0.1,
  },
} as const;

export function unitPriceIdr() {
  return PULANGIN.pricing.unitPriceIdr;
}

/** Jaga Semesta share per rorak: 20% of Rp 10.000 = Rp 2.000. */
export function platformFeeIdr() {
  return Math.round(PULANGIN.pricing.unitPriceIdr * PULANGIN.pricing.platformSharePct);
}

/** Builder share per rorak: 80% of Rp 10.000 = Rp 8.000. */
export function builderFeeIdr() {
  return PULANGIN.pricing.unitPriceIdr - platformFeeIdr();
}

export function orderTotalIdr(qty: number) {
  return qty * unitPriceIdr();
}
