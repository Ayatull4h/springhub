// INTEGRATION POINTS with the live SpringHub codebase.
// Everything that depends on code I could not see lives in this file.
// Each function works as-is through the live HTTP API, but the repo owner
// should swap the bodies for direct calls to the existing helpers.

import type { Role, SessionUser } from "./types";

const SITE = process.env.NEXT_PUBLIC_SITE_URL ?? "https://springhub.id";

/**
 * 1. AUTH. The live site exposes GET /api/auth/me -> { user: {...} | null }.
 * Forwarding the cookie works without knowing the auth library.
 * TODO(repo owner): replace with the server-side session helper.
 */
export async function getSessionUser(req: Request): Promise<SessionUser | null> {
  const cookie = req.headers.get("cookie");
  if (!cookie) return null;
  const res = await fetch(new URL("/api/auth/me", req.url || SITE), {
    headers: { cookie },
    cache: "no-store",
  });
  if (!res.ok) return null;
  const { user } = (await res.json()) as { user: Record<string, unknown> | null };
  if (!user) return null;
  const rawRole = String(user.role ?? "volunteer").toLowerCase();
  const role: Role = (["public", "volunteer", "field_lead", "admin"] as const).includes(rawRole as Role)
    ? (rawRole as Role)
    : rawRole.includes("admin")
      ? "admin"
      : "volunteer";
  return {
    id: String(user.id),
    username: String(user.username ?? user.name ?? "pengguna"),
    role,
  };
}

export function isReviewer(u: SessionUser | null) {
  return !!u && (u.role === "admin" || u.role === "field_lead");
}

/**
 * 2. PHOTO STORAGE. Live report photos use storagePath like
 * "reports/<reportId>/<timestamp>-<rand>.jpg".
 * TODO(repo owner): call the same uploader the /api/reports route uses.
 */
export async function storePhoto(_path: string, _bytes: Buffer, _contentType: string): Promise<string> {
  throw new Error("storePhoto(): wire to the live SpringHub storage uploader");
}

/**
 * 3. MIRROR INTO LIVE REPORTS. An approved rorak becomes a normal
 * trench-development report, so it shows on the map, dashboard and gives the
 * builder the live +500 points. Field ids match the live form (GET /api/forms).
 * TODO(repo owner): call the internal report-creation function and mark the
 * report "approved" in the same transaction, so it is not reviewed twice.
 */
export function toLiveTrenchReport(u: {
  builderName: string;
  builderPhone: string | null;
  orderCode: string;
  springCode: string | null;
  capturedAt: Date;
  lat: number;
  lng: number;
  accuracyM: number;
  structureType: string;
  shape: string;
  lengthCm: number;
  widthCm: number;
  depthCm: number;
  position: string | null;
  fillMaterial: string | null;
  photoPath: string;
}) {
  return {
    formSlug: "trench-development",
    status: "approved",
    values: {
      A_tanggal: u.capturedAt.toISOString().slice(0, 10),
      A_nama: u.builderName,
      A_wa: u.builderPhone ?? "",
      A_kegiatan: "Pulangkan Air Hujan ke Rumahnya",
      A_geotag: { lat: u.lat, lng: u.lng },
      A_akurasi_gps: Math.round(u.accuracyM),
      A_kode_event: u.orderCode,
      A_kode_spring: u.springCode ?? "",
      R1_jenis: u.structureType,
      R2_bentuk: u.shape,
      R3_panjang: u.lengthCm,
      R3_lebar: u.widthCm,
      R3_kedalaman_kotak: u.depthCm,
      R4_foto: u.photoPath,
      R5_posisi: u.position ?? "",
      R6_bahan: u.fillMaterial ?? "",
    },
  };
}

export async function mirrorToLiveReports(_payload: ReturnType<typeof toLiveTrenchReport>): Promise<string | null> {
  // Returns the new report id. Until wired, units stay linked with reportId = null.
  return null;
}

/**
 * 4. PRECISE SPRING LOCATION. The public /api/springs only exposes the 5 km
 * snapped point, so an order "for spring X" would otherwise need a 3 km area.
 * TODO(repo owner): return the precise spring coordinates from the DB.
 * Builders only see the precise area after they claim a slot.
 */
export async function resolveSpringCenter(_springId: string): Promise<{ lat: number; lng: number } | null> {
  return null;
}
