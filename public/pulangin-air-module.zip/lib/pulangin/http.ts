import { NextResponse } from "next/server";

/** English for every API error. The client shows `error` or `errorEn` by the locale cookie. */
const EN: [RegExp | string, string | ((m: RegExpMatchArray) => string)][] = [
  ["Aksi tidak valid", "Invalid action"],
  ["Alasan penolakan wajib diisi (dikirim ke pembuat)", "A rejection reason is required (it is sent to the builder)"],
  ["Bank dan nomor rekening wajib", "Bank and account number are required"],
  ["Body tidak valid", "Invalid request body"],
  ["Foto rorak wajib", "A pit photo is required"],
  ["Geotag tidak valid", "Invalid geotag"],
  ["Lokasi harus di Indonesia", "The location must be in Indonesia"],
  ["Lokasi tidak valid", "Invalid location"],
  ["Nama pemilik lahan wajib (izin lahan)", "The landowner's name is required (land permission)"],
  ["Pilih mata air", "Choose a spring"],
  ["Target tidak valid", "Invalid target"],
  ["Waktu foto tidak valid", "Invalid photo time"],
  ["Masuk dulu untuk melihat pesanan Anda", "Sign in to see your orders"],
  ["Masuk dulu untuk memesan", "Sign in to order"],
  ["Masuk dulu untuk mengambil tugas", "Sign in to take tasks"],
  ["Masuk dulu", "Please sign in first"],
  ["Khusus admin / field lead", "Admins and field leads only"],
  ["Khusus admin", "Admins only"],
  ["Tidak boleh memverifikasi rorak sendiri", "You can't verify your own pit"],
  ["Klaim tidak ditemukan", "Claim not found"],
  ["Pesanan tidak ditemukan", "Order not found"],
  ["Unit tidak ditemukan", "Pit not found"],
  ["Klaim sudah tidak aktif", "This claim is no longer active"],
  ["Lengkapi dan verifikasi rekening pembayaran dulu", "Add and verify your payout account first"],
  ["Pesanan tidak menunggu tinjauan area", "This order is not waiting for a site review"],
  ["Semua slot pada klaim ini sudah dilaporkan", "Every slot on this claim has been reported"],
  ["Unit sudah diputuskan", "This pit has already been decided"],
  ["Gagal mengambil slot", "Couldn't claim the slots"],
  ["Foto terlalu besar", "The photo is too large"],
  ["Format foto tidak didukung", "Unsupported photo format"],
  ["Rekening tidak dapat divalidasi. Periksa bank dan nomornya.", "The account couldn't be validated. Check the bank and number."],
  ["Pesanan tidak tersedia", "This order is not available"],
  ["Tidak bisa mengambil pesanan sendiri", "You can't take your own order"],
  ["Pesanan sudah lewat masa berlaku", "This order has expired"],
  ["Jumlah slot tidak valid", "Invalid number of slots"],
  [/^Jumlah rorak (\d+) sampai (\d+)$/, (m) => `Between ${m[1]} and ${m[2]} pits`],
  [/^Hanya tersisa (\d+) slot$/, (m) => `Only ${m[1]} slots left`],
  [/^Maksimal (\d+) slot aktif per pembuat\..*$/, (m) => `At most ${m[1]} active slots per builder. Finish your current ones first.`],
];

export function toEnglish(id: string): string {
  for (const [k, v] of EN) {
    if (typeof k === "string") {
      if (k === id) return v as string;
    } else {
      const m = id.match(k);
      if (m) return typeof v === "function" ? v(m) : v;
    }
  }
  return id;
}

export const ok = <T,>(data: T, init?: number) => NextResponse.json(data, { status: init ?? 200 });
export const fail = (status: number, error: string) =>
  NextResponse.json({ error, errorEn: toEnglish(error) }, { status });

export function int(v: unknown, fallback = NaN) {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? Math.round(n) : fallback;
}

export function num(v: unknown, fallback = NaN) {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export function str(v: unknown, max = 200): string {
  return typeof v === "string" ? v.trim().slice(0, max) : "";
}
