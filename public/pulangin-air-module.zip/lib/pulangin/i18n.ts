// ID/EN copy for Pulangkan Air Hujan ke Rumahnya / Return Water Home.
// The live springhub.id stores the language in a `locale` cookie (set by the
// header's ID/EN toggle); this module reads and writes the same cookie.
// Terminology: "rorak" (ID) = "infiltration pit" (EN).

import { PULANGIN, builderFeeIdr, platformFeeIdr, unitPriceIdr } from "./config";

export type Lang = "id" | "en";
export const LOCALE_COOKIE = "locale";

export function normalizeLang(v: string | null | undefined): Lang {
  return v && v.toLowerCase().startsWith("en") ? "en" : "id";
}

export function rupiah(n: number) {
  return "Rp " + new Intl.NumberFormat("id-ID").format(Math.round(n));
}

const g = PULANGIN.geo;
const tm = PULANGIN.timing;
const sp = PULANGIN.spec;
const price = rupiah(unitPriceIdr());
const builder = rupiah(builderFeeIdr());
const platform = rupiah(platformFeeIdr());
const builderPct = Math.round((1 - PULANGIN.pricing.platformSharePct) * 100);
const platformPct = Math.round(PULANGIN.pricing.platformSharePct * 100);

const id = {
  lang: "id" as Lang,
  locale: "id-ID",
  title: "Pulangkan Air Hujan ke Rumahnya",
  tagline: "Return Water Home",
  unit: "rorak",
  units: (n: number) => `${n} rorak`,
  nav: { home: "Beranda", order: "Pesan Rorak", build: "Jadi Pembuat", mine: "Pesanan Saya", review: "Verifikasi" },
  langSwitch: "Bahasa",

  home: {
    lead:
      "Rorak adalah parit kecil yang menahan limpasan hujan agar meresap dan mengisi kembali air tanah yang memberi makan mata air. Anda memesan, warga setempat menggali dan dibayar, SpringHub memverifikasi setiap rorak.",
    ctaOrder: `Pesan rorak · ${price}`,
    ctaBuild: `Jadi pembuat rorak · ${builder}/rorak`,
    priceNote: `${price} per rorak: ${builderPct}% (${builder}) untuk pembuat, ${platformPct}% (${platform}) untuk verifikasi admin dan platform springhub.id oleh Jaga Semesta.`,
    specTitle: "Spesifikasi minimum rorak",
    specL: "Panjang",
    specW: "Lebar",
    specD: "Dalam",
    specNote: "Searah kontur, di daerah resapan. Tidak di lereng curam atau tepi tebing. Dengan izin pemilik lahan.",
    forBuyer: "Untuk pemesan",
    forBuilder: "Untuk pembuat rorak",
    buyerSteps: [
      ["Pilih lokasi", "Mata air yang ingin dijaga, atau biarkan SpringHub memilih daerah resapan prioritas."],
      ["Bayar", "Lewat Midtrans: QRIS, e-wallet, virtual account, kartu. Dana ditahan sampai rorak terbukti dibuat."],
      ["Terima laporan", "Foto dan geotag setiap rorak, terverifikasi tim SpringHub, tampil di halaman pesanan Anda."],
    ] as [string, string][],
    builderSteps: [
      ["Ambil tugas", `Pilih pesanan di dekat Anda dan klaim beberapa slot. Waktu pengerjaan ${tm.claimHoldDays} hari.`],
      ["Gali dan foto", `Tulis kode pesanan di patok atau kertas, foto dari aplikasi dengan GPS ≤ ${g.maxGpsAccuracyM} m.`],
      ["Dibayar", `Setelah terverifikasi (target ${tm.reviewSlaDays} hari), ${builder} per rorak ditransfer ke rekening atau e-wallet Anda.`],
    ] as [string, string][],
    trustTitle: "Bagaimana kami memastikan rorak benar-benar ada",
    trust: [
      "Foto diambil langsung dari kamera aplikasi, dengan kode pesanan, waktu dan koordinat tercetak di foto.",
      `Akurasi GPS wajib ≤ ${g.maxGpsAccuracyM} m dan titik harus di dalam area pesanan.`,
      `Satu petak ±22 m maksimal ${g.cellCapacity} rorak dari semua pesanan, jadi satu lokasi tidak bisa dijual dua kali.`,
      "Foto yang sama atau mirip (dipotong, dikompres ulang) otomatis ditolak.",
      "Setiap rorak dicek admin sebelum uang dikirim, dan sebagian dipilih acak untuk cek lapangan.",
      "Rorak yang lolos tercatat juga di peta dan dashboard SpringHub.",
    ],
    openTitle: "Pesanan yang sedang mencari pembuat",
    allTasks: "Semua tugas →",
    noOpen: "Belum ada pesanan terbuka. Jadilah pemesan pertama.",
  },

  card: {
    pickedBySpringhub: "Lokasi pilihan SpringHub",
    area: (r: string) => `Area ${r}`,
    perUnit: "/ rorak",
    slots: (n: number) => `${n} slot`,
    view: "Lihat →",
    claim: "Ambil",
    slotsLabel: "Jumlah slot",
    verifyAccountFirst: "Verifikasi rekening dulu",
  },

  status: {
    awaiting_payment: "Menunggu pembayaran",
    area_review: "Tinjauan lokasi",
    open: "Mencari pembuat",
    in_progress: "Sedang dibuat",
    fulfilled: "Air sudah pulang",
    expired: "Kedaluwarsa",
    cancelled: "Dibatalkan",
  },
  unitStatus: {
    pending_review: "Menunggu verifikasi",
    flagged: "Perlu dicek",
    field_audit: "Cek lapangan",
    approved: "Terverifikasi",
    rejected: "Ditolak",
  },
  progress: { verified: "Terverifikasi", of: (d: number, t: number) => `${d}/${t} rorak` },
  loading: "Memuat…",
  signIn: "Masuk",

  order: {
    heading: "Pesan rorak",
    sub: "Dana Anda ditahan dan baru dibayarkan ke pembuat setelah rorak terverifikasi.",
    step1: "1. Di mana air hujan dipulangkan?",
    targets: {
      springhub_pick: ["Pilihan SpringHub", "Daerah resapan prioritas"],
      spring: ["Mata air tertentu", "Dari peta SpringHub"],
      custom_pin: ["Lokasi saya", "Ditinjau field lead dulu"],
    } as Record<"springhub_pick" | "spring" | "custom_pin", [string, string]>,
    spring: "Mata air",
    pickSpring: "Pilih mata air…",
    regency: "Kabupaten / kota",
    pinHint: "Ketuk peta untuk menaruh titik. Field lead memastikan lahan aman dan ada izin sebelum pesanan dibuka.",
    pickedRegency: "Ditentukan SpringHub",
    step2: "2. Berapa rorak?",
    qtyLabel: "Jumlah rorak",
    credit: "Nama yang ditampilkan",
    creditHint: "Kosongkan untuk memakai nama akun. Tulis 'Anonim' bila tidak ingin ditampilkan.",
    message: "Pesan untuk pembuat (opsional)",
    email: "Email untuk bukti dan laporan",
    fallback: `Jika belum semua rorak dibuat dalam ${tm.orderExpiryDays} hari`,
    fallbackReallocate: "Alihkan ke lokasi prioritas SpringHub",
    fallbackRefund: "Kembalikan dana untuk rorak yang belum dibuat",
    summary: "Ringkasan",
    lineBuilder: `Bayaran pembuat rorak (${builderPct}%)`,
    linePlatform: `Verifikasi admin dan platform springhub.id oleh Jaga Semesta (${platformPct}%)`,
    total: "Total",
    pay: "Bayar dengan Midtrans",
    paying: "Membuka pembayaran…",
    methods: "QRIS, GoPay, ShopeePay, DANA, OVO, virtual account, kartu.",
    needLocation: "Tentukan lokasi dulu",
  },

  mine: { heading: "Pesanan saya", empty: "Belum ada pesanan.", first: "Pesan rorak pertama Anda" },

  detail: {
    paid: (s: string) => `Dibayar ${s}`,
    awaiting: "Pembayaran belum kami terima. Bila sudah membayar, halaman ini akan diperbarui dalam beberapa menit.",
    areaReview: "Field lead sedang meninjau lokasi Anda (izin lahan, kemiringan, daerah resapan). Pesanan dibuka setelah disetujui.",
    precision: "Titik ditampilkan dengan ketelitian ±110 m untuk melindungi lokasi mata air dan lahan warga.",
    reports: (n: number) => `Laporan rorak (${n})`,
    none: "Belum ada rorak terverifikasi.",
    unitN: (n: number) => `Rorak #${n}`,
  },

  build: {
    heading: "Jadi pembuat rorak",
    sub: `${builder} per rorak terverifikasi (${builderPct}% dari ${price}), plus poin SpringHub untuk setiap laporan rorak yang disetujui.`,
    signInToClaim: "Masuk untuk mengambil tugas",
    claimed: (n: number) => `Berhasil mengambil ${n} slot. Selesaikan dalam ${tm.claimHoldDays} hari.`,
    active: "Tugas aktif",
    owed: (o: number, s: number) => `${o} dari ${s} rorak belum dilaporkan`,
    due: (d: string) => `Batas ${d}`,
    rejected: (r: string) => `Ditolak: ${r}`,
    report: "Lapor rorak",
    paidOut: "Sudah ditransfer:",
    open: "Pesanan terbuka",
    openHint: "Lokasi pasti terlihat setelah Anda mengambil slot.",
    noOpen: "Belum ada pesanan terbuka.",
    payTo: (b: string, n: string, a: string) => `Bayaran ke ${b} ${n} a.n. ${a}`,
    change: "Ubah",
    acctTitle: "Rekening untuk menerima bayaran",
    bank: "Bank / e-wallet",
    acctNo: "Nomor rekening / HP",
    acctHint: "Nama pemilik dicek otomatis ke bank.",
    save: "Simpan",
    checking: "Mengecek…",
  },

  report: {
    back: "Tugas saya",
    heading: (c: string) => `Lapor rorak · ${c}`,
    remaining: (o: number, s: number) => `Sisa ${o} dari ${s}.`,
    instruction: (c: string) => `Tulis ${c} di patok atau kertas dan pastikan terlihat di foto bersama rorak dan alat ukur.`,
    rejectedTitle: "Rorak ditolak otomatis",
    sentTitle: "Laporan terkirim, menunggu verifikasi",
    area: "Area pesanan",
    thisUnit: "Rorak ini",
    type: "Jenis",
    shape: "Bentuk penampang",
    length: "Panjang (cm)",
    width: "Lebar (cm)",
    depth: "Kedalaman (cm)",
    min: (n: number) => `Minimal ${n} cm`,
    position: "Posisi",
    fill: "Bahan isian",
    owner: "Nama pemilik lahan",
    ownerPhone: "No. HP pemilik lahan",
    ownerPhoneHint: "Hanya untuk verifikasi, tidak ditampilkan.",
    consent: "Pemilik lahan sudah mengizinkan rorak ini dibuat dan difoto.",
    send: "Kirim laporan rorak",
    sending: "Mengirim…",
    allDone: `Semua slot sudah dilaporkan. Bayaran dikirim setelah verifikasi (target ${tm.reviewSlaDays} hari).`,
    loading: "Memuat tugas…",
    types: { Rorak: "Rorak", "Parit Resapan": "Parit Resapan" } as Record<string, string>,
    shapes: { Kotak: "Kotak", Persegi: "Persegi" } as Record<string, string>,
    positions: { "Area Resapan": "Area Resapan", "Pinggir Jalan": "Pinggir Jalan", "Di Antara Tanaman": "Di Antara Tanaman", Lereng: "Lereng", Lainnya: "Lainnya" } as Record<string, string>,
    fills: { Kosong: "Kosong", Batu: "Batu", Ijuk: "Ijuk", "Daun/Seresah": "Daun/Seresah", Kompos: "Kompos", Lainnya: "Lainnya" } as Record<string, string>,
  },

  capture: {
    noGps: "Perangkat tidak mendukung GPS",
    camError: "Kamera tidak bisa dibuka. Izinkan akses kamera, atau gunakan unggah foto.",
    gpsError: (m: string) => `GPS: ${m}`,
    acc: (a: number, ready: boolean) =>
      `Akurasi GPS ±${a} m ${ready ? "· siap" : `· tunggu sampai ≤ ${g.maxGpsAccuracyM} m, cari tempat terbuka`}`,
    searching: "Mencari sinyal GPS…",
    shoot: "Ambil foto rorak",
    retake: "Foto ulang",
    photoAlt: "Foto rorak",
    galleryPre: "Kamera bermasalah?",
    galleryLink: "Unggah dari galeri",
    galleryPost: "(akan ditandai untuk dicek manual)",
  },

  review: {
    heading: "Verifikasi rorak",
    sub: "Cek: kode pesanan terbaca, alat ukur terlihat, rorak searah kontur, bukan lereng curam.",
    runPayouts: "Kirim bayaran yang antre",
    processing: "Memproses…",
    payoutResult: (ok: number, units: number, failed: number) => `${ok} transfer dibuat (${units} rorak). ${failed} gagal.`,
    empty: "Antrean kosong.",
    owner: "lahan",
    note: "Catatan (wajib bila ditolak, dikirim ke pembuat)",
    approve: "Setujui",
    reject: "Tolak",
    audit: "Cek lapangan",
  },
};

export type Dict = typeof id;

const en: Dict = {
  lang: "en",
  locale: "en-GB",
  title: "Return Water Home",
  tagline: "Pulangkan Air Hujan ke Rumahnya",
  unit: "infiltration pit",
  units: (n: number) => `${n} infiltration pit${n === 1 ? "" : "s"}`,
  nav: { home: "Home", order: "Order Pits", build: "Become a Builder", mine: "My Orders", review: "Verification" },
  langSwitch: "Language",

  home: {
    lead:
      "An infiltration pit (rorak) is a small trench that holds rain runoff so it soaks in and recharges the groundwater that feeds springs. You order, local people dig and get paid, SpringHub verifies every pit.",
    ctaOrder: `Order a pit · ${price}`,
    ctaBuild: `Become a pit builder · ${builder}/pit`,
    priceNote: `${price} per pit: ${builderPct}% (${builder}) to the builder, ${platformPct}% (${platform}) for admin verification and the springhub.id platform by Jaga Semesta.`,
    specTitle: "Minimum pit specification",
    specL: "Length",
    specW: "Width",
    specD: "Depth",
    specNote: "Dug along the contour, in a recharge area. Not on steep slopes or cliff edges. With the landowner's permission.",
    forBuyer: "For buyers",
    forBuilder: "For pit builders",
    buyerSteps: [
      ["Choose a location", "A spring you want to protect, or let SpringHub pick a priority recharge area."],
      ["Pay", "Via Midtrans: QRIS, e-wallets, virtual account, card. Funds are held until each pit is proven built."],
      ["Get the report", "A geotagged photo of every pit, verified by the SpringHub team, shown on your order page."],
    ],
    builderSteps: [
      ["Take a task", `Pick an order near you and claim a few slots. You have ${tm.claimHoldDays} days to finish.`],
      ["Dig and photograph", `Write the order code on a stake or paper, take the photo in the app with GPS ≤ ${g.maxGpsAccuracyM} m.`],
      ["Get paid", `Once verified (target ${tm.reviewSlaDays} days), ${builder} per pit is sent to your bank account or e-wallet.`],
    ],
    trustTitle: "How we make sure every pit really exists",
    trust: [
      "Photos are taken live in the app camera, with the order code, time and coordinates stamped on the image.",
      `GPS accuracy must be ≤ ${g.maxGpsAccuracyM} m and the point must be inside the order area.`,
      `Each ±22 m cell holds at most ${g.cellCapacity} pits across all orders, so one spot can't be sold twice.`,
      "The same or a similar photo (cropped, re-compressed) is rejected automatically.",
      "An admin checks every pit before money moves, and some are picked at random for a field check.",
      "Approved pits are also recorded on the SpringHub map and dashboard.",
    ],
    openTitle: "Orders looking for builders",
    allTasks: "All tasks →",
    noOpen: "No open orders yet. Be the first to order.",
  },

  card: {
    pickedBySpringhub: "Location chosen by SpringHub",
    area: (r: string) => `${r} area`,
    perUnit: "/ pit",
    slots: (n: number) => `${n} slot${n === 1 ? "" : "s"}`,
    view: "View →",
    claim: "Claim",
    slotsLabel: "Number of slots",
    verifyAccountFirst: "Verify your payout account first",
  },

  status: {
    awaiting_payment: "Awaiting payment",
    area_review: "Site review",
    open: "Looking for builders",
    in_progress: "Being built",
    fulfilled: "Water is home",
    expired: "Expired",
    cancelled: "Cancelled",
  },
  unitStatus: {
    pending_review: "Awaiting verification",
    flagged: "Needs a check",
    field_audit: "Field check",
    approved: "Verified",
    rejected: "Rejected",
  },
  progress: { verified: "Verified", of: (d: number, t: number) => `${d}/${t} pits` },
  loading: "Loading…",
  signIn: "Sign in",

  order: {
    heading: "Order infiltration pits",
    sub: "Your payment is held and only paid to builders once each pit is verified.",
    step1: "1. Where should the rainwater go home?",
    targets: {
      springhub_pick: ["SpringHub's choice", "Priority recharge area"],
      spring: ["A specific spring", "From the SpringHub map"],
      custom_pin: ["My location", "Reviewed by a field lead first"],
    },
    spring: "Spring",
    pickSpring: "Choose a spring…",
    regency: "Regency / city",
    pinHint: "Tap the map to drop a pin. A field lead confirms the land is safe and permitted before the order opens.",
    pickedRegency: "Set by SpringHub",
    step2: "2. How many pits?",
    qtyLabel: "Number of pits",
    credit: "Display name",
    creditHint: "Leave empty to use your account name. Write 'Anonymous' to stay hidden.",
    message: "Message to builders (optional)",
    email: "Email for receipt and reports",
    fallback: `If not every pit is built within ${tm.orderExpiryDays} days`,
    fallbackReallocate: "Move it to a SpringHub priority site",
    fallbackRefund: "Refund the pits not built",
    summary: "Summary",
    lineBuilder: `Pit builder pay (${builderPct}%)`,
    linePlatform: `Admin verification and springhub.id platform by Jaga Semesta (${platformPct}%)`,
    total: "Total",
    pay: "Pay with Midtrans",
    paying: "Opening payment…",
    methods: "QRIS, GoPay, ShopeePay, DANA, OVO, virtual account, card.",
    needLocation: "Set a location first",
  },

  mine: { heading: "My orders", empty: "No orders yet.", first: "Order your first pits" },

  detail: {
    paid: (s: string) => `Paid ${s}`,
    awaiting: "We haven't received the payment yet. If you've paid, this page updates within a few minutes.",
    areaReview: "A field lead is reviewing your site (land permission, slope, recharge area). The order opens once approved.",
    precision: "Points are shown to ±110 m to protect springs and people's land.",
    reports: (n: number) => `Pit reports (${n})`,
    none: "No verified pits yet.",
    unitN: (n: number) => `Pit #${n}`,
  },

  build: {
    heading: "Become a pit builder",
    sub: `${builder} per verified pit (${builderPct}% of ${price}), plus SpringHub points for every approved pit report.`,
    signInToClaim: "Sign in to take tasks",
    claimed: (n: number) => `Claimed ${n} slot${n === 1 ? "" : "s"}. Finish within ${tm.claimHoldDays} days.`,
    active: "Active tasks",
    owed: (o: number, s: number) => `${o} of ${s} pits not reported yet`,
    due: (d: string) => `Due ${d}`,
    rejected: (r: string) => `Rejected: ${r}`,
    report: "Report a pit",
    paidOut: "Paid out:",
    open: "Open orders",
    openHint: "The exact location is shown after you claim a slot.",
    noOpen: "No open orders yet.",
    payTo: (b: string, n: string, a: string) => `Paid to ${b} ${n}, ${a}`,
    change: "Change",
    acctTitle: "Account to receive payouts",
    bank: "Bank / e-wallet",
    acctNo: "Account / phone number",
    acctHint: "The account holder's name is checked with the bank automatically.",
    save: "Save",
    checking: "Checking…",
  },

  report: {
    back: "My tasks",
    heading: (c: string) => `Report a pit · ${c}`,
    remaining: (o: number, s: number) => `${o} of ${s} left.`,
    instruction: (c: string) => `Write ${c} on a stake or paper and make sure it shows in the photo with the pit and a measuring tape.`,
    rejectedTitle: "Pit rejected automatically",
    sentTitle: "Report sent, awaiting verification",
    area: "Order area",
    thisUnit: "This pit",
    type: "Type",
    shape: "Cross-section",
    length: "Length (cm)",
    width: "Width (cm)",
    depth: "Depth (cm)",
    min: (n: number) => `At least ${n} cm`,
    position: "Position",
    fill: "Fill material",
    owner: "Landowner's name",
    ownerPhone: "Landowner's phone",
    ownerPhoneHint: "Only used for verification, never shown.",
    consent: "The landowner has agreed to this pit being dug and photographed.",
    send: "Send pit report",
    sending: "Sending…",
    allDone: `Every slot has been reported. Payment is sent after verification (target ${tm.reviewSlaDays} days).`,
    loading: "Loading task…",
    types: { Rorak: "Infiltration pit (rorak)", "Parit Resapan": "Infiltration trench" },
    shapes: { Kotak: "Box", Persegi: "Square" },
    positions: { "Area Resapan": "Recharge area", "Pinggir Jalan": "Roadside", "Di Antara Tanaman": "Between crops", Lereng: "Slope", Lainnya: "Other" },
    fills: { Kosong: "Empty", Batu: "Stones", Ijuk: "Palm fibre", "Daun/Seresah": "Leaves/litter", Kompos: "Compost", Lainnya: "Other" },
  },

  capture: {
    noGps: "This device doesn't support GPS",
    camError: "The camera couldn't open. Allow camera access, or upload a photo instead.",
    gpsError: (m: string) => `GPS: ${m}`,
    acc: (a: number, ready: boolean) =>
      `GPS accuracy ±${a} m ${ready ? "· ready" : `· wait until ≤ ${g.maxGpsAccuracyM} m, move to open ground`}`,
    searching: "Searching for GPS…",
    shoot: "Take pit photo",
    retake: "Retake",
    photoAlt: "Pit photo",
    galleryPre: "Camera trouble?",
    galleryLink: "Upload from gallery",
    galleryPost: "(it will be flagged for a manual check)",
  },

  review: {
    heading: "Verify pits",
    sub: "Check: order code readable, measuring tape visible, pit along the contour, not on a steep slope.",
    runPayouts: "Send queued payouts",
    processing: "Processing…",
    payoutResult: (ok: number, units: number, failed: number) => `${ok} transfers created (${units} pits). ${failed} failed.`,
    empty: "The queue is empty.",
    owner: "land",
    note: "Note (required when rejecting, sent to the builder)",
    approve: "Approve",
    reject: "Reject",
    audit: "Field check",
  },
};

export const DICTS: Record<Lang, Dict> = { id, en };

/** Spec values stay in the live form's Indonesian option values; labels are translated. */
export const SPEC_TYPES = sp.allowedTypes;
export const SPEC_SHAPES = sp.allowedShapes;
