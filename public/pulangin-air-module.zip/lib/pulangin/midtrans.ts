// Midtrans: Snap for buyer payment, Iris for builder payouts.
// Server-only. The live site already uses Midtrans for donations; if it has
// its own Midtrans helper, point these functions at it and keep one set of keys.
//
// Env:
//   MIDTRANS_SERVER_KEY       Snap / Core API server key
//   MIDTRANS_IS_PRODUCTION    "true" in production
//   IRIS_CREATOR_KEY          Iris API key with "creator" role
//   IRIS_APPROVER_KEY         Iris API key with "approver" role
//   NEXT_PUBLIC_SITE_URL      https://springhub.id

import crypto from "node:crypto";

const prod = process.env.MIDTRANS_IS_PRODUCTION === "true";
const SNAP_BASE = prod ? "https://app.midtrans.com/snap/v1" : "https://app.sandbox.midtrans.com/snap/v1";
const CORE_BASE = prod ? "https://api.midtrans.com/v2" : "https://api.sandbox.midtrans.com/v2";
const IRIS_BASE = prod ? "https://app.midtrans.com/iris/api/v1" : "https://app.sandbox.midtrans.com/iris/api/v1";

function basic(key: string | undefined) {
  if (!key) throw new Error("Midtrans/Iris key is not configured");
  return "Basic " + Buffer.from(key + ":").toString("base64");
}

async function call<T>(url: string, key: string | undefined, init: RequestInit = {}): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: basic(key),
      ...(init.headers ?? {}),
    },
    cache: "no-store",
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`Midtrans ${res.status}: ${text.slice(0, 300)}`);
  return JSON.parse(text) as T;
}

// ---------- Snap (buyer pays) ----------

export type SnapInput = {
  midtransOrderId: string; // unique per attempt, e.g. `${order.code}-${Date.now()}`
  grossIdr: number;
  quantity: number;
  unitPriceIdr: number;
  orderCode: string;
  customer: { firstName: string; email?: string | null; phone?: string | null };
  finishUrl: string;
};

export async function createSnapTransaction(i: SnapInput) {
  return call<{ token: string; redirect_url: string }>(`${SNAP_BASE}/transactions`, process.env.MIDTRANS_SERVER_KEY, {
    method: "POST",
    body: JSON.stringify({
      transaction_details: { order_id: i.midtransOrderId, gross_amount: i.grossIdr },
      item_details: [
        {
          id: "pulangin-air-rorak",
          price: i.unitPriceIdr,
          quantity: i.quantity,
          name: `Rorak / infiltration pit (${i.orderCode})`.slice(0, 50),
        },
      ],
      customer_details: {
        first_name: i.customer.firstName,
        email: i.customer.email ?? undefined,
        phone: i.customer.phone ?? undefined,
      },
      callbacks: { finish: i.finishUrl },
      expiry: { unit: "hours", duration: 24 },
    }),
  });
}

/** SHA512(order_id + status_code + gross_amount + server_key). */
export function verifySnapSignature(n: {
  order_id: string;
  status_code: string;
  gross_amount: string;
  signature_key: string;
}) {
  const key = process.env.MIDTRANS_SERVER_KEY ?? "";
  const expected = crypto
    .createHash("sha512")
    .update(n.order_id + n.status_code + n.gross_amount + key)
    .digest("hex");
  const a = Buffer.from(expected);
  const b = Buffer.from(n.signature_key ?? "");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/** Never trust the webhook body alone: re-read the status from Midtrans. */
export async function getTransactionStatus(midtransOrderId: string) {
  return call<{
    transaction_status: string;
    fraud_status?: string;
    gross_amount: string;
    status_code: string;
  }>(`${CORE_BASE}/${encodeURIComponent(midtransOrderId)}/status`, process.env.MIDTRANS_SERVER_KEY);
}

export type PaymentOutcome = "paid" | "pending" | "failed" | "refunded";

export function mapTransactionStatus(s: { transaction_status: string; fraud_status?: string }): PaymentOutcome {
  switch (s.transaction_status) {
    case "settlement":
      return "paid";
    case "capture":
      return s.fraud_status === "accept" ? "paid" : "pending";
    case "pending":
      return "pending";
    case "refund":
    case "partial_refund":
      return "refunded";
    default:
      return "failed"; // deny, cancel, expire, failure
  }
}

// ---------- Iris (builder gets paid) ----------

export type IrisPayoutItem = {
  beneficiary_name: string;
  beneficiary_account: string;
  beneficiary_bank: string;
  beneficiary_email?: string;
  amount: string; // Iris expects a decimal string
  notes: string; // max ~100 chars, keep ASCII
};

export async function createPayouts(items: IrisPayoutItem[]) {
  return call<{ payouts: { status: string; reference_no: string }[] }>(
    `${IRIS_BASE}/payouts`,
    process.env.IRIS_CREATOR_KEY,
    { method: "POST", body: JSON.stringify({ payouts: items }) }
  );
}

/**
 * Approve queued payouts. Depending on the Iris account setup this may need
 * an OTP from the approver; if so, approval stays a manual step in the
 * Iris dashboard and this function is not called.
 */
export async function approvePayouts(referenceNos: string[], otp?: string) {
  return call<{ status: string }>(`${IRIS_BASE}/payouts/approve`, process.env.IRIS_APPROVER_KEY, {
    method: "POST",
    body: JSON.stringify({ reference_nos: referenceNos, ...(otp ? { otp } : {}) }),
  });
}

export async function getPayout(referenceNo: string) {
  return call<{ status: string; reference_no: string; amount: string }>(
    `${IRIS_BASE}/payouts/${encodeURIComponent(referenceNo)}`,
    process.env.IRIS_CREATOR_KEY
  );
}

/** Check a bank account before saving it, so payouts don't bounce. */
export async function validateBankAccount(bank: string, account: string) {
  return call<{ account_name: string; account_no: string; bank_name: string }>(
    `${IRIS_BASE}/account_validation?bank=${encodeURIComponent(bank)}&account=${encodeURIComponent(account)}`,
    process.env.IRIS_CREATOR_KEY
  );
}
