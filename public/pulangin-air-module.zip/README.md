# Pulangkan Air Hujan ke Rumahnya (EN: Return Water Home)

A marketplace module for springhub.id. People who want infiltration pits (rorak) built **order and pay** for them. Local people **claim slots, dig the pits and report** with a live photo and geotag. Jaga Semesta verifies each pit and **then** pays the builder.

Terminology: Indonesian UI says "rorak"; English copy says "infiltration pit". It works like e-commerce, except the "delivery" is a verified field report.

Route: `https://springhub.id/pulangin-air`

## Fit with the live site (checked 19 Oct 2026)

| Live springhub.id | How this module matches |
| --- | --- |
| Next.js App Router, Tailwind, dark theme via `html.dark` | Next 14 App Router pages. Only the live utility classes are used (`card`, `chip`, `btn-primary`, `btn-secondary`, `btn-ghost`, `input`, `container-page`, `text-ink*`, `border-ink-line`), so light/dark follows the site. |
| `GET /api/auth/me` → `{ user }` | `lib/pulangin/integration.ts#getSessionUser` forwards the cookie to it. Replace with the server session helper. |
| `trench-development` form (`A_geotag`, `A_akurasi_gps` max 15 m, `A_kode_event`, `R1_jenis`…`R6_bahan`) | Delivery fields and options mirror it. `toLiveTrenchReport()` maps an approved rorak 1:1 into that form, so it shows on the map and dashboard and earns the live +500 points. |
| `/api/springs` (public, 5 km snapped) | The order page lists springs from it. `resolveSpringCenter()` should return the precise point server-side. |
| Midtrans for donations | Snap for buyer payment, Iris for builder payouts (`lib/pulangin/midtrans.ts`). |
| Leaflet + OpenStreetMap | Same (`components/pulangin/area-map.tsx`). |
| UUID ids, camelCase JSON, ISO dates | Same. |
| ID/EN toggle in the header, stored in a `locale` cookie | Every page is bilingual (`lib/pulangin/i18n.ts`). The layout reads the same `locale` cookie, and the module's own ID/EN switch writes it, so both stay in sync. API errors return `error` (ID) and `errorEn`; check results carry `detail` and `detailEn`. Form option values stay in Indonesian to match the live trench form; only their labels are translated. |

The local `SpringHub/` folder on Fa's Mac is an **older snapshot** (Xendit, light theme, hardcoded forms) and is not the deployed source. Merge this module into the deployed repo, not that folder.

## Files

```
app/pulangin-air/                      microsite
  layout.tsx                           sub-nav, ID/EN switch, metadata per language
  page.tsx                             landing: two roles, rules, open orders
  pesan/page.tsx                       buyer: location, quantity, pay (Midtrans Snap)
  pesanan/page.tsx, pesanan/[id]       buyer: my orders, delivery report
  tugas/page.tsx                       builder: payout account, job board, active tasks
  tugas/[claimId]/page.tsx             builder: live camera + GPS report, one rorak per submit
  verifikasi/page.tsx                  admin / field lead review queue + payout run
app/api/pulangin/
  orders (GET, POST), orders/[id] (GET), orders/[id]/claims (POST)
  claims (GET), claims/[id]/units (POST multipart)
  admin/units (GET), admin/units/[id] (POST), admin/orders/[id] (POST), admin/payouts (POST)
  midtrans/notify (POST), iris/notify (POST), cron (GET), payout-account (GET, PUT)
components/pulangin/                   ui, lang (ID/EN context + switch), area-map, live-capture, open-orders
lib/pulangin/
  config.ts       every business rule and number (edit here)
  i18n.ts         all ID/EN copy (rorak = infiltration pit)
  checks.ts       automatic verification, pure function
  state.ts        order/claim state rules, pure functions
  geo.ts, phash.ts
  midtrans.ts     Snap, signature check, status API, Iris payouts
  db.ts           Prisma client + role-aware serializers
  integration.ts  THE ONLY FILE WITH TODOs FOR THE REPO OWNER
prisma/pulangin-air.prisma               models to paste into schema.prisma
tests/pulangin.test.ts                   22 tests, `npx tsx --test tests/pulangin.test.ts`
```

## Flow

```
Buyer:   pesan ──pay (Snap)──▶ awaiting_payment ──webhook──▶ open (or area_review for own pin)
Builder: claim N slots (14 days) ──▶ dig, write order code on stake, live photo + GPS ──▶ unit
Checks:  fail ─▶ rejected (slot returns to builder)   flag ─▶ flagged   clean ─▶ pending_review (10% field_audit)
Review:  human approves ──▶ payout queued ──▶ Iris batch per builder ──▶ paid
Order:   all units approved ──▶ fulfilled  |  past 90 days ──▶ expired ──▶ buyer's fallback (reallocate / refund)
```

## How "no replication in the same area" is enforced

Phone GPS error is up to 15 m, so "one rorak per exact point" can't be enforced. These rules can:

1. **Cell cap.** The map is split into ~22 m cells. Each cell holds at most `cellCapacity` (3) rorak across **all** orders. A 4th fails automatically, so one hillside can't be sold to many buyers.
2. **Photo fingerprint.** A dHash of every photo. A re-used, re-compressed or cropped photo fails (tested).
3. **Order code in the photo.** The builder writes the code (e.g. `PA-7K3Q`) on a stake. The app also burns code, time and coordinates into the image. Reviewers confirm it's readable.
4. **Points within 3 m** of another rorak are flagged for a human, not failed (could be GPS noise).
5. **Capture window and freshness.** The photo must be taken after the claim and uploaded within 30 minutes (72 h if queued offline, flagged).
6. **Human approval before money moves**, plus a random 10% field audit.

## Setup

1. Paste `prisma/pulangin-air.prisma` models into the live schema and run `prisma migrate dev -n pulangin_air`.
2. Copy `app/`, `components/pulangin/`, `lib/pulangin/` into the repo. Add `sharp` if it's not already a dependency.
3. Env: `MIDTRANS_SERVER_KEY`, `MIDTRANS_IS_PRODUCTION`, `IRIS_CREATOR_KEY`, `IRIS_APPROVER_KEY`, `NEXT_PUBLIC_SITE_URL`, `CRON_SECRET`.
4. Midtrans dashboard: notification URL → `/api/pulangin/midtrans/notify`. If the donation flow already owns the single notification URL, forward order ids starting with `PA-` from that handler.
5. Iris: request Iris activation from Midtrans (it's a separate product), set the callback to `/api/pulangin/iris/notify`.
6. Cron: `GET /api/pulangin/cron` hourly and `POST /api/pulangin/admin/payouts` daily, both with `Authorization: Bearer $CRON_SECRET`.
7. Fill the TODOs in `lib/pulangin/integration.ts` (auth, photo storage, mirror to reports, precise spring point) and `photoUrl()` in `components/pulangin/ui.tsx`.
8. Add "Pulangkan Air Hujan" (EN "Return Water Home") to the header nav and `/pulangin-air/verifikasi` to the admin menu.

## Decisions to confirm (defaults in `config.ts`)

- **Price.** Buyer pays Rp 10.000 per infiltration pit. 80% (Rp 8.000) goes to the builder; 20% (Rp 2.000) goes to Jaga Semesta for admin verification and the springhub.id platform. Set in `pricing.unitPriceIdr` and `pricing.platformSharePct`.
- **Fee split shown to buyers?** `showFeeBreakdown: true` (80/20 shown at checkout).
- **Gateway and payout fees** are not deducted separately; they come out of the 20% share. Check the numbers before launch: a flat virtual-account fee on a small order can exceed the platform share.
- **Minimum spec.** 100 × 30 × 30 cm per pit, rorak or parit resapan, box section.
- **Expiry fallback.** Default "reallocate"; refunds are reported to admin by the cron, not executed automatically, because not every Midtrans method supports API refunds.
