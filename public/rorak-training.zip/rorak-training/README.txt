MODUL PELATIHAN: Pulangkan Air ke Rumahnya lewat Rorak
Jaga Semesta, #MusimIniAgakLain. Versi 1, November 2026.

ISI FOLDER
  index.html                  halaman pelatihan (HTML, CSS, JS dalam satu file)
  assets/logo-jaga-semesta.png
  assets/rorak-bulat.jpg
  assets/rorak-kotak.jpg
  assets/rorak-memanjang.jpg

CARA PASANG (pilih salah satu)

1. Halaman sendiri (paling mudah)
   Unggah seluruh folder "rorak-training" ke server, misalnya ke
   jagasemesta.org/rorak-training/ . Halaman langsung bisa dibuka di
   https://jagasemesta.org/rorak-training/
   Jangan pisahkan index.html dari folder assets.

2. Disisipkan di halaman lain (WordPress, dll.)
   Setelah langkah 1, tempel kode ini di blok HTML kustom:

   <iframe src="https://jagasemesta.org/rorak-training/"
           title="Pelatihan Rorak Jaga Semesta"
           style="width:100%; height:90vh; border:0; border-radius:12px"
           loading="lazy"></iframe>

CATATAN TEKNIS
  - Tidak butuh database, server-side, atau build. File statis saja.
  - Font memakai Google Fonts (Plus Jakarta Sans, JetBrains Mono). Kalau
    situs memblokir domain luar, halaman tetap jalan dengan font sistem.
  - Pilihan bahasa, progres modul, checklist, dan jawaban kuis disimpan di
    localStorage browser peserta. Tidak ada data yang terkirim ke server,
    jadi admin TIDAK bisa melihat siapa yang sudah selesai. Untuk absensi
    atau sertifikat, pakai formulir terpisah.
  - Tema terang/gelap mengikuti pengaturan perangkat peserta.
  - Tombol laporan mengarah ke https://springhub.id/report/trench-development
  - Membuka index.html langsung dari komputer (file://) juga bisa untuk uji coba.

MENGUBAH ISI
  Teks Indonesia ada di elemen class="id", teks Inggris di class="en".
  Ubah keduanya bersamaan. Soal kuis dan checklist ada di bagian <script>
  (variabel QUIZ dan CHECK).
