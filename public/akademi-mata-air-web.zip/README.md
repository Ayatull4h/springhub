# Akademi Penjaga Mata Air, Modul 1 dan 2

Halaman statis, tanpa build step, tanpa dependensi server.

## Cara pasang
1. Salin seluruh isi folder ini ke direktori web, misalnya `/akademi/mata-air/`.
2. Buka `index.html`. Selesai.

Struktur:
- `index.html` : seluruh konten (ID dan EN dalam satu file, dikontrol atribut `data-lang`)
- `assets/style.css` : gaya, termasuk mode gelap otomatis
- `assets/app.js` : toggle bahasa dan logika kuis
- `assets/*.jpg|png` : logo dan foto lapangan

## Ganti foto
Timpa file di `assets/` dengan nama yang sama. Ukuran disarankan 800 px sisi terpanjang.
- `cover-hero.jpg` : latar hero
- `rheocrene.jpg`, `limnocrene.jpg`, `hanging-garden.jpg` : foto per tipe

Untuk menambah foto tipe lain (Helocrene, Hillslope, Cave), tambahkan di dalam `<div class="vis">` pada artikel tipe terkait:
```html
<figure class="ph"><img src="assets/NAMA.jpg" alt=""><figcaption><span class="l-id">Foto lapangan</span><span class="l-en">Field photo</span></figcaption></figure>
```

## Ganti teks
Setiap teks dua bahasa ditulis berpasangan:
```html
<span class="l-id">teks Indonesia</span><span class="l-en">English text</span>
```
Ubah keduanya agar kedua bahasa tetap sinkron.

## Bahasa default
`app.js` memulai dengan `id` dan mengingat pilihan pengguna di localStorage. Ubah `var saved='id'` menjadi `'en'` untuk default Inggris.

## Font
Fraunces dan Source Sans 3 dimuat dari Google Fonts. Kalau website harus offline atau tanpa pihak ketiga, hapus tag `<link>` Google Fonts di `index.html`; halaman jatuh ke Georgia dan system sans.

## Tautan laporan
Tombol "Buka formulir pemantauan" mengarah ke https://springhub.id/report/spring-monitoring (ada di `index.html`, bagian `#lapor`).
