(function(){
  var root=document.documentElement;
  function setLang(l){root.setAttribute('data-lang',l);document.getElementById('lang-id').setAttribute('aria-pressed',l==='id');document.getElementById('lang-en').setAttribute('aria-pressed',l==='en');try{localStorage.setItem('lang',l)}catch(e){}}
  var saved='id';try{saved=localStorage.getItem('lang')||'id'}catch(e){}
  setLang(saved);
  document.getElementById('lang-id').onclick=function(){setLang('id')};
  document.getElementById('lang-en').onclick=function(){setLang('en')};
  var total=8,answered=0,correct=0;
  function update(){var s=document.getElementById('score');if(answered<total){s.hidden=true;return}s.hidden=false;
    var ok=correct>=6;s.innerHTML=(root.getAttribute('data-lang')==='en'?'Score: ':'Skor: ')+correct+' / '+total+(ok?(root.getAttribute('data-lang')==='en'?' . Ready for the field.':' . Siap ke lapangan.'):(root.getAttribute('data-lang')==='en'?' . Review Module 2 and retake.':' . Ulang Modul 2 lalu coba lagi.'));}
  document.querySelectorAll('.opt').forEach(function(b){b.addEventListener('click',function(){
    var q=b.closest('.q');if(q.classList.contains('done'))return;q.classList.add('done');
    var ans=+q.dataset.ans,i=+b.dataset.i;answered++;if(i===ans)correct++;
    q.querySelectorAll('.opt').forEach(function(o){if(+o.dataset.i===ans)o.classList.add('right');else if(o===b)o.classList.add('wrong')});
    q.querySelector('.exp').hidden=false;update();});});
  document.getElementById('reset').onclick=function(){answered=0;correct=0;document.querySelectorAll('.q').forEach(function(q){q.classList.remove('done');q.querySelectorAll('.opt').forEach(function(o){o.classList.remove('right','wrong')});q.querySelector('.exp').hidden=true});update();document.getElementById('kuis').scrollIntoView();};
  document.getElementById('quiz').addEventListener('submit',function(e){e.preventDefault()});
})();
